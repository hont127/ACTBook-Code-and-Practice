﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class DashFlashMove : MonoBehaviour
    {
        public Rigidbody selfRigidbody;

        public Collider testCollider;
        public Transform testTransform;

        public bool testBlinkOrDash;


        void Start()
        {
            var rigidbody = GetComponent<Rigidbody>();
            rigidbody.position = transform.position;
            if (testBlinkOrDash)
                BlinkTo(transform, transform.position + transform.forward * 3f);
            else
                StartCoroutine(DashTo(rigidbody, testTransform.position, 30f));
        }

        void BlinkTo(Transform trans, Vector3 dstPoint)
        {
            //trans是正在瞬移的对象，dstPoint是目标点。
            var diff = (dstPoint - trans.position);//距离差向量
            var length = diff.magnitude;//目标长度
            var dir = diff.normalized;//目标方向

            var hit = default(RaycastHit);
            if (selfRigidbody.SweepTest(dir, out hit, length))//对瞬移目的地进行SweepTest测试
            {
                //返回true说明碰到了障碍物
                var dstClosestPoint = hit.point;
                var selfClosestPoint = selfRigidbody.ClosestPointOnBounds(dstClosestPoint);//自己相对于目标的边界点
                var closestPointDiff = selfClosestPoint - transform.position;//边界点距离差
                transform.position = dstClosestPoint - closestPointDiff;//移动到障碍物的合适位置
            }
            else
            {
                trans.position = dstPoint;//没有碰到障碍物，瞬移到目标点
            }
        }

        IEnumerator DashTo(Rigidbody rigidbody, Vector3 dstPoint, float speed)
        {
            //trans是正在瞬移的对象，dstPoint是目标点。
            dstPoint = GetGroundPoint(dstPoint);//此处为自定义函数，修正到准确的地面位置

            var waitForFixedUpdate = new WaitForFixedUpdate();
            var beginTime = Time.fixedTime;//此处是物理更新时序。
            for (var duration = 0.15f; Time.fixedTime - beginTime <= duration;)
            {
                var t = (Time.fixedTime - beginTime) / duration;
                t = t * t;//逐渐加速缓动

                rigidbody.velocity = (dstPoint - rigidbody.position).normalized * speed;

                yield return waitForFixedUpdate;
            }
        }

        Vector3 GetGroundPoint(Vector3 referencePoint)
        {
            return referencePoint;
        }
    }
}
