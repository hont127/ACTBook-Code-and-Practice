﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class GroundDetecteTest : MonoBehaviour
    {
        public Transform[] groundPoints;
        public LayerMask layerMask;
        public float length = 1f;


        void Update()
        {
            var isOnGround = false;
            var raycastHit = default(RaycastHit);
            IsOnGroundUpdate(groundPoints, layerMask, length, out isOnGround, out raycastHit);
            Debug.Log("isOnGround: " + isOnGround);
        }

        void OnDrawGizmos()
        {
            for (int i = 0; i < groundPoints.Length; i++)
            {
                var item = groundPoints[i];

                var p0 = item.position;
                var p1 = p0 + (-item.up) * length;

                Gizmos.DrawLine(p0, p1);
            }
        }

        void IsOnGroundUpdate(Transform[] groundPoints, LayerMask layerMask, float length, out bool isOnGround, out RaycastHit cacheRaycastHit)
        {
            isOnGround = false;
            cacheRaycastHit = default(RaycastHit);//初始化数值
            for (int i = 0, iMax = groundPoints.Length; i < iMax; i++)//遍历所有地面检测点
            {
                var groundPoint = groundPoints[i];
                var hit = default(RaycastHit);
                var isHit = Physics.Raycast(new Ray(groundPoint.position, -groundPoint.up), out hit, length, layerMask);//射线检测
                if (isHit)
                {
                    isOnGround = isHit;
                    cacheRaycastHit = hit;//缓存结果多次使用
                    break;//检测到即刻跳出
                }
            }
        }
    }
}
