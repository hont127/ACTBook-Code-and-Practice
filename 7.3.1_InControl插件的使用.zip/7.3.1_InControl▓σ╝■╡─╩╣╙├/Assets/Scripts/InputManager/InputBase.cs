﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public abstract class InputBase
    {
        public abstract int ID { get; }
        public abstract bool IsPress { get; }
        public abstract bool IsPressDown { get; }
        public abstract bool IsPressUp { get; }
        public abstract float AxisValue { get; }
    }
}
