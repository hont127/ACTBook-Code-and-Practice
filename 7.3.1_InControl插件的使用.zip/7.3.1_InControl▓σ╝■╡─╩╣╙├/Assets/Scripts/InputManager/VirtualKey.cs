﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class VirtualKey : MonoBehaviour
    {
        enum EKeyState { IsPress, IsPressDown, IsPressUp }
        InputBase[] mInputBaseArray;

        public bool IsPress { get { return KeyStateDetecte(EKeyState.IsPressUp); } }
        public bool IsPressDown { get { return KeyStateDetecte(EKeyState.IsPressUp); } }
        public bool IsPressUp { get { return KeyStateDetecte(EKeyState.IsPressUp); } }


        public VirtualKey(params InputBase[] inputBases)
        {
            mInputBaseArray = inputBases;
        }

        public int[] ConvertToInputIDArray()
        {
            return Array.ConvertAll(mInputBaseArray, m => m.ID);
        }

        bool KeyStateDetecte(EKeyState state)
        {
            var flag = false;
            for (int i = 0; i < mInputBaseArray.Length; i++)
            {
                switch (state)
                {
                    case EKeyState.IsPress:
                        if (mInputBaseArray[i].IsPressUp)
                            flag = true;
                        break;
                    case EKeyState.IsPressDown:
                        if (mInputBaseArray[i].IsPressDown)
                            flag = true;
                        break;
                    case EKeyState.IsPressUp:
                        if (mInputBaseArray[i].IsPressUp)
                            flag = true;
                        break;
                }
            }
            return flag;
        }
    }
}
