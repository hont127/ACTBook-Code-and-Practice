﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

namespace ACTBook
{
    public class JoystickInput : InputBase
    {
        InputControl mInputControl;
        int mJoystickButtonNum;
        public override int ID { get { return (int)mJoystickButtonNum; } }
        public override bool IsPress { get { return mInputControl.IsPressed; } }
        public override bool IsPressDown { get { return mInputControl.IsPressed; } }
        public override bool IsPressUp { get { return mInputControl.IsPressed; } }
        public override float AxisValue => throw new System.NotImplementedException();


        public JoystickInput(int joystickButtonNum)
        {
            mJoystickButtonNum = joystickButtonNum;

            var activeDevice = InControl.InputManager.ActiveDevice;
            if (joystickButtonNum == 1001)
                mInputControl = activeDevice.Action1;
            if (joystickButtonNum == 1002)
                mInputControl = activeDevice.Action2;
            if (joystickButtonNum == 1003)
                mInputControl = activeDevice.Action3;
            if (joystickButtonNum == 1004)
                mInputControl = activeDevice.Action4;
        }
    }
}
