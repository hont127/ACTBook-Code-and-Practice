﻿using System;
using UnityEngine;

namespace ACTBook
{
    public class InputUtil
    {
        public static InputBase CreateInputBase(int id)
        {
            if (id > 1000 && id < 10000)//手柄输入
            {
                return new JoystickInput(id);
            }
            else if (id > 1000_000)//键盘轴类型输入
            {
                var value1 = id / 1000;
                var value2 = id % 1000;
                return new KeyboardInput((KeyCode)value1, (KeyCode)value2);
            }
            else//键盘输入
            {
                return new KeyboardInput((KeyCode)id);
            }
        }

        public static void ListenAnyInput(Action<int> onReceived)//改键缺省方法；开启新按键监听
        {
            //TODO
            //可通过内部开启协程进行监听
        }

        public static void EndInputListen()//改键缺省方法；关闭按键监听
        {
            //TODO
            //可关闭内部协程结束监听
        }
    }
}
