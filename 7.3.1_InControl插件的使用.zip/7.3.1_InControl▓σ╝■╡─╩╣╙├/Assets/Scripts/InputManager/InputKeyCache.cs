﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;

namespace ACTBook
{
    public class InputKeyCache : MonoBehaviour
    {
        public VirtualKey Attack { get; private set; }
        public VirtualKey Jump { get; private set; }
        public VirtualKey MoveAxis { get; private set; }


        void Awake()
        {
            var joystickInputBase = InputUtil.CreateInputBase(1001);
            var keyboardInputBase = InputUtil.CreateInputBase((int)KeyCode.J);
            Jump = new VirtualKey(joystickInputBase, keyboardInputBase);

            joystickInputBase = InputUtil.CreateInputBase(1002);
            keyboardInputBase = InputUtil.CreateInputBase((int)KeyCode.K);
            Attack = new VirtualKey(joystickInputBase, keyboardInputBase);

            joystickInputBase = InputUtil.CreateInputBase(1003);
            keyboardInputBase = InputUtil.CreateInputBase((int)KeyCode.K);
            MoveAxis = new VirtualKey(joystickInputBase, keyboardInputBase);

            var inputDevice = InControl.InputManager.ActiveDevice;
            Debug.Log("Action1:" + inputDevice.Action1.IsPressed);//方块(X)
            Debug.Log("Action2:" + inputDevice.Action2.IsPressed);//叉(A)
            Debug.Log("Action3:" + inputDevice.Action3.IsPressed);//圆圈(B)
            Debug.Log("Action4:" + inputDevice.Action4.IsPressed);//三角(Y)
            Debug.Log("LeftStick:" + inputDevice.LeftStick.Value);//左摇杆
            Debug.Log(" InputDevice.LeftBumper:" + inputDevice.LeftBumper);//L1
            Debug.Log(" InputDevice.RightBumper:" + inputDevice.RightBumper);//R1
            Debug.Log(" InputDevice.LeftTrigger:" + inputDevice.LeftTrigger.Value);//L2
            Debug.Log(" InputDevice.RightTrigger:" + inputDevice.RightTrigger.Value);//R2
            Debug.Log(" InputDevice.RightStickButton:" + inputDevice.RightStickButton);//L3
            Debug.Log(" InputDevice.LeftStickButton:" + inputDevice.LeftStickButton);//R3
            inputDevice.SetLightColor(Color.red);//PS4 Light
            inputDevice.Vibrate(0.5f, 0.5f);//震动
        }
    }
}
