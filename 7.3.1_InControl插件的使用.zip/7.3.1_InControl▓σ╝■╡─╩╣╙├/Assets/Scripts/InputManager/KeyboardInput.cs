﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class KeyboardInput : InputBase
    {
        KeyCode mKeyCode;
        KeyCode mAxisKeyCode;
        public override int ID { get { return (int)mKeyCode; } }
        public override bool IsPress { get { return Input.GetKey(mKeyCode); } }
        public override bool IsPressDown { get { return Input.GetKeyDown(mKeyCode); } }
        public override bool IsPressUp { get { return Input.GetKeyUp(mKeyCode); } }
        public override float AxisValue { get { return Input.GetKey(mKeyCode) ? 1 : Input.GetKey(mAxisKeyCode) ? -1 : 0; } }

        public KeyboardInput(KeyCode keyCode, KeyCode axisKeyCode = KeyCode.A)
        {
            mKeyCode = keyCode;
            mAxisKeyCode = axisKeyCode;
        }
    }
}
