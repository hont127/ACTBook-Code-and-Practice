﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public interface ISkill : ISkillBase
    {
        void OnTemplateRegist();//模板注册回调
        void OnTemplateUnregist();//模板反注册回调
        ISkillBase Instantiate(SkillContext skillContext);//技能对象实例化
    }
}
