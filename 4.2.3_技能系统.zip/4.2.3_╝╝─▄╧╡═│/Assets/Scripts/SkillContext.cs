﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public struct SkillContext
    {
        public GameObject GameObject { get; set; }//技能释放者引用
    }
}