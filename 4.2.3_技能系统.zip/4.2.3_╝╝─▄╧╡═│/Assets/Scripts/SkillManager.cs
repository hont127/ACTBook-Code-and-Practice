﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class SkillManager : MonoBehaviour
    {
        static bool mIsDestroying;
        static SkillManager mInstance;//单例对象
        public static SkillManager Instance
        {
            get
            {
                if (mIsDestroying) return null;
                if (mInstance == null)
                {
                    mInstance = new GameObject("[SkillManager]").AddComponent<SkillManager>();
                    DontDestroyOnLoad(mInstance.gameObject);
                }
                return mInstance;
            }
        }
        Dictionary<int, ISkill> mSkillTemplateDict;//技能模板字典

        void Awake()
        {
            mSkillTemplateDict = new Dictionary<int, ISkill>(10);
        }
        void OnDestroy()
        {
            mIsDestroying = true;//单例处理
        }
        public void RegistToTemplate(ISkill skill)//模板注册
        {
            mSkillTemplateDict.Add(skill.ID, skill);
        }
        public bool UnregistFromTemplate(int skillID)//模板反注册
        {
            return mSkillTemplateDict.Remove(skillID);
        }
        public ISkillBase InstantiateSkill(int skillID, SkillContext skillContext)//技能实例化
        {
            return mSkillTemplateDict[skillID].Instantiate(skillContext);
        }
    }
}