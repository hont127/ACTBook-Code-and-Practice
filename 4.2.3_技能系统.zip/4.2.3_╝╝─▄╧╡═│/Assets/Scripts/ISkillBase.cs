﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public interface ISkillBase
    {
        int ID { get; }//技能ID
        void SerializeRecovery(SkillContext skillContext);//序列化恢复
        void Execute(Action onFinished);//技能执行
    }
}