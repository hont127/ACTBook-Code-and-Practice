﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class ShadowFx : MonoBehaviour
    {
        const string SHADOW_FX_NAME_PREFIX = "Shadow_";
        public Shader shader;//透明边缘泛光Shader
        public SkinnedMeshRenderer skinnedMeshRenderer;//蒙皮网格
        public float fadeTime = 0.5f;//淡出时间
        public MonoBehaviour coroutineMonoBehaviour;
        //协程开启对象，防止因自身关闭导致残影协程停止
        GameObject mShadowFxGO;

        void OnEnable()
        {
            coroutineMonoBehaviour.StartCoroutine(ShadowFxTrigger());//残影特效触发协程
        }
        void OnDestroy()
        {
            if (mShadowFxGO)//特殊情况残影销毁处理
                Destroy(mShadowFxGO);
        }
        IEnumerator ShadowFxTrigger()
        {
            mShadowFxGO = new GameObject(SHADOW_FX_NAME_PREFIX + Time.time);
            mShadowFxGO.transform.position = skinnedMeshRenderer.transform.position;
            mShadowFxGO.transform.rotation = skinnedMeshRenderer.transform.rotation;
            mShadowFxGO.transform.localScale = skinnedMeshRenderer.transform.localScale;
            //拷贝变换信息
            var meshRenderer = mShadowFxGO.AddComponent<MeshRenderer>();
            var meshFilter = mShadowFxGO.AddComponent<MeshFilter>();
            var mesh = new Mesh() { name = mShadowFxGO.name };
            skinnedMeshRenderer.BakeMesh(mesh);//烘焙残影
            meshFilter.sharedMesh = mesh;
            var mat = new Material(shader);
            mat.CopyPropertiesFromMaterial(skinnedMeshRenderer.sharedMaterial);
            //从主材质球拷贝参数
            meshRenderer.sharedMaterial = mat;
            var cacheMatColor = mat.color;
            var beginTime = Time.time;
            for (var duration = fadeTime; Time.time - beginTime <= duration;)
            {
                var t = (Time.time - beginTime) / duration;
                mat.color = new Color(cacheMatColor.r, cacheMatColor.g, cacheMatColor.b, Mathf.Lerp(1f, 0f, t));
                yield return null;
            }//残影消隐插值
            Destroy(mShadowFxGO);//销毁残影
        }
    }
}
