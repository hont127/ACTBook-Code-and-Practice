﻿using UnityEditor;
using UnityEngine;

namespace ACTBook
{
    [CustomEditor(typeof(Enemy_Type1))]
    public class Enemy_Type1Inspector : Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();//首先更新序列化对象

            var hpProp = serializedObject.FindProperty("hp");
            var speedProp = serializedObject.FindProperty("speed");
            var atkProp = serializedObject.FindProperty("atk");

            using (var change = new EditorGUI.ChangeCheckScope())//监测GUI内容改变
            {
                EditorGUILayout.PropertyField(hpProp, new GUIContent("Enemy hp"));
                EditorGUILayout.PropertyField(speedProp, new GUIContent("Enemy speed"));
                EditorGUILayout.PropertyField(atkProp, new GUIContent("Enemy atk"));

                if (GUILayout.Button("preset1"))
                {
                    hpProp.intValue = 100;
                    speedProp.floatValue = 600;
                    atkProp.intValue = 6;
                }

                if (GUILayout.Button("preset2"))
                {
                    hpProp.intValue = 200;
                    speedProp.floatValue = 550;
                    atkProp.intValue = 4;
                }

                if (change.changed)//如果改变则应用修改
                {
                    serializedObject.ApplyModifiedProperties();
                }
            }
        }

        //该脚本是否存在PreviewGUI
        public override bool HasPreviewGUI()
        {
            return true;
        }

        //这里填写PreviewGUI的标题
        public override GUIContent GetPreviewTitle()
        {
            return new GUIContent("Enemy_Type1 Debug");
        }

        //进行PreviewGUI的绘制
        public override void OnPreviewGUI(Rect r, GUIStyle background)
        {
            base.OnPreviewGUI(r, background);

            GUILayout.Box("Enemy State:...");
        }
    }
}
