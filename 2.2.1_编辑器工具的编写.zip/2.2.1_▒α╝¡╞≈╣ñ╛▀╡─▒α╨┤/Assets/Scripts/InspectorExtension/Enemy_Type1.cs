﻿using UnityEngine;

namespace ACTBook
{
    public class Enemy_Type1 : MonoBehaviour
    {
        public int hp = 100;
        public float speed = 300;
        public int atk = 10;
    }
}
