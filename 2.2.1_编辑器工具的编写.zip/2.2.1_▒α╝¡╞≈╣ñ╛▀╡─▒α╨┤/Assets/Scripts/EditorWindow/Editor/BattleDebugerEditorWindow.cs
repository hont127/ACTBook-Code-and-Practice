﻿using UnityEditor;
using UnityEngine;

namespace ACTBook
{
    public class BattleDebugerEditorWindow : EditorWindow
    {
        public float debugTimeScale;


        [MenuItem("Tools/Battle Debuger")]//unity建议将自定义的插件启动项置于Tools目录
        static void Setup()
        {
            GetWindow<BattleDebugerEditorWindow>();//在这个静态方法中执行窗口的创建
        }

        void OnGUI()//绘制窗口的GUI内容
        {
            debugTimeScale = EditorGUILayout.FloatField("debug timeScale", debugTimeScale);

            if (GUILayout.Button("Generate Enemy_Type1"))
            {
                //...
            }

            if (GUILayout.Button("Generate Enemy_Type1 x10"))
            {
                //...
            }

            if (GUILayout.Button("Killed All Enemy"))
            {
                //...
            }
        }

        void Awake()
        {
            SceneView.duringSceneGui += OnSceneGUIDelegateBind;
        }

        void OnDestroy()
        {
            SceneView.duringSceneGui -= OnSceneGUIDelegateBind;
        }

        void OnSceneGUIDelegateBind(SceneView sceneView)
        {
            var enemies = GetEnemies();
            for (int i = 0; i < enemies.Length; i++)
            {
                var enemy = enemies[i];
                Handles.DrawWireCube(enemy.Position, new Vector3(0.5f, 1f, 0.5f));
            }
        }

        //---调试数据---
        struct EnemyInfo { public Vector3 Position { get; set; } }

        EnemyInfo[] GetEnemies() { return new EnemyInfo[] { new EnemyInfo() { Position = new Vector3(0f, 0f, 0f) }, new EnemyInfo() { Position = new Vector3(1.5f, 0f, 0f) } }; }
        //---调试数据---

    }
}
