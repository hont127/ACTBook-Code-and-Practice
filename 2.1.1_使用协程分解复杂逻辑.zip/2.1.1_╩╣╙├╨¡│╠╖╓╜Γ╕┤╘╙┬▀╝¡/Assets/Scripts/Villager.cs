﻿using System;
using System.Collections;
using UnityEngine;

namespace ACTBook
{
    //该脚本定义了村民的基础字段和逻辑
    public class Villager : MonoBehaviour
    {
        const float DOT_CHECK_ANGLE = 45f;

        const int MOVE_ERROR_MAX = 20000;
        const float MOVE_IN_RANGE_EPS = 0.001f;

        [SerializeField]
        SpriteRenderer spriteRenderer = null;
        [SerializeField]
        Sprite sideSprite = null;
        [SerializeField]
        Sprite upSprite = null;
        [SerializeField]
        Sprite downSprite = null;
        [SerializeField]
        float moveSpeed = 0.5f;

        [SerializeField]
        Transform[] toEatPathArray = null;
        [SerializeField]
        Transform[] toSleepPathArray = null;

        public float Satiation { get; set; }
        public float Fatigue { get; set; }


        public IEnumerator Eat(Action onAte)
        {
            yield return MoveTo(Array.ConvertAll(toEatPathArray, m => m.position), moveSpeed);
            onAte?.Invoke();
            yield return new WaitForSeconds(1f);
            var pointsReverse = Array.ConvertAll(toEatPathArray, m => m.position);
            Array.Reverse(pointsReverse);
            yield return MoveTo(pointsReverse, moveSpeed);
        }

        public IEnumerator Sleep(Action onSlept)
        {
            yield return MoveTo(Array.ConvertAll(toSleepPathArray, m => m.position), moveSpeed);
            onSlept?.Invoke();
            yield return new WaitForSeconds(1f);
            var pointsReverse = Array.ConvertAll(toSleepPathArray, m => m.position);
            Array.Reverse(pointsReverse);
            yield return MoveTo(pointsReverse, moveSpeed);
        }

        IEnumerator MoveTo(Vector3[] pathPointArray, float speed)
        {
            for (int i = 0; i < pathPointArray.Length; i++)
            {
                var item = pathPointArray[i];

                var pointReferenceDir = Vector3.forward;
                if (i > 0)
                    pointReferenceDir = pathPointArray[i] - pathPointArray[i - 1];
                else
                    pointReferenceDir = pathPointArray[i] - transform.position;

                var dot = 1f;
                var isInRadius = false;
                var errorCount = 0;

                var moveDirection = (item - transform.position).normalized;

                if (moveDirection.normalized != Vector3.zero)
                    ChangeDirectionSprite(moveDirection);

                do
                {
                    if (errorCount > MOVE_ERROR_MAX)
                    {
                        Debug.LogError("Path Move Looping Error!");
                        break;
                    }
                    errorCount++;

                    transform.position += moveDirection * Time.deltaTime * speed;

                    var referenceDirection = (item - transform.position).normalized;
                    dot = Vector3.Dot(pointReferenceDir.normalized, referenceDirection);
                    isInRadius = Vector3.Distance(item, transform.position) <= MOVE_IN_RANGE_EPS;

                    yield return null;

                } while (dot > 0 && !isInRadius);
            }
        }

        void ChangeDirectionSprite(Vector3 direction)
        {
            if (DotCheck(direction, new Vector3(0f, 1f, 0f)))
            {
                spriteRenderer.sprite = upSprite;
                spriteRenderer.transform.localScale = new Vector3(1f, 1f, 1f);
            }

            else if (DotCheck(direction, new Vector3(0f, -1f, 0f)))
            {
                spriteRenderer.sprite = downSprite;
                spriteRenderer.transform.localScale = new Vector3(1f, 1f, 1f);
            }

            else if (DotCheck(direction, new Vector3(1f, 0f, 0f)))
            {
                spriteRenderer.sprite = sideSprite;
                spriteRenderer.transform.localScale = new Vector3(1f, 1f, 1f);
            }

            else if (DotCheck(direction, new Vector3(-1f, 0f, 0f)))
            {
                spriteRenderer.sprite = sideSprite;
                spriteRenderer.transform.localScale = new Vector3(-1f, 1f, 1f);
            }
        }

        bool DotCheck(Vector3 srcDir, Vector3 compareDir)
        {
            var dot = Vector3.Dot(srcDir, compareDir);
            var acos = Mathf.Acos(dot);
            var deg = acos * Mathf.Rad2Deg;
            return deg < DOT_CHECK_ANGLE;
        }
    }
}
