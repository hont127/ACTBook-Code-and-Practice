﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class Villager : MonoBehaviour
    {
        const float FATIGUE_DEFAULT_VALUE = 12f;//疲倦默认值
        const float SATIATION_DEFAULT_VALUE = 5f;//饱食度默认值

        const float FATIGUE_MIN_VALUE = 0.3f;//疲倦最小值
        const float SATIATION_MIN_VALUE = 0.2f;//饱食度最小值

        float mSatiation;
        float mFatigue;

        Coroutine mActionCoroutine;//当前动作协程


        void OnEnable()
        {
            mSatiation = SATIATION_DEFAULT_VALUE;
            mFatigue = FATIGUE_DEFAULT_VALUE;
            //数值初始化

            StartCoroutine(Tick());
        }

        IEnumerator Tick()//状态刷新循环
        {
            while (true)
            {
                mSatiation = Mathf.Max(0, mSatiation - Time.deltaTime);
                mFatigue = Mathf.Max(0, mFatigue - Time.deltaTime);

                if (mSatiation <= SATIATION_MIN_VALUE && mActionCoroutine == null)
                    mActionCoroutine = StartCoroutine(EatFood());

                if (mFatigue <= FATIGUE_MIN_VALUE)
                    mActionCoroutine = StartCoroutine(Sleep());

                yield return null;
            }
        }

        IEnumerator EatFood()//处理吃食物具体动作
        {
            yield return new WaitForSeconds(2f);

            mSatiation = SATIATION_DEFAULT_VALUE;
            mActionCoroutine = null;
        }

        IEnumerator Sleep()//处理睡觉具体动作
        {
            yield return new WaitForSeconds(2f);

            mFatigue = FATIGUE_DEFAULT_VALUE;
            mActionCoroutine = null;
        }

        void OnGUI()
        {
            GUILayout.Box("Satiation: " + mSatiation);
            GUILayout.Box("Fatigue: " + mFatigue);
        }
    }
}
