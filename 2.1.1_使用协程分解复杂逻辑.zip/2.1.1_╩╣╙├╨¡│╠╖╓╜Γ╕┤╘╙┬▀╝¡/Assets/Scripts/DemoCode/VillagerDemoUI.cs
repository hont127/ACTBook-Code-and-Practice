﻿using UnityEngine;
using UnityEngine.UI;

namespace ACTBook
{
    /// <summary>
    /// 该脚本为演示Demo的UI脚本。
    /// </summary>
    public class VillagerDemoUI : MonoBehaviour
    {
        [SerializeField]
        Villager villager = null;

        [SerializeField]
        Image satiationImage = null;

        [SerializeField]
        Image fatigueImage = null;


        void Update()
        {
            satiationImage.fillAmount = villager.Satiation / VillagerFSM.SATIATION_DEFAULT_VALUE;
            fatigueImage.fillAmount = villager.Fatigue / VillagerFSM.FATIGUE_DEFAULT_VALUE;
        }
    }
}
