﻿using System.Collections;
using UnityEngine;

namespace ACTBook
{
    public class VillagerFSM : MonoBehaviour
    {
        public const float FATIGUE_DEFAULT_VALUE = 12f;//疲倦默认值
        public const float SATIATION_DEFAULT_VALUE = 5f;//饱食度默认值

        public const float FATIGUE_MIN_VALUE = 0.3f;//疲倦最小值
        public const float SATIATION_MIN_VALUE = 0.2f;//饱食度最小值

        [SerializeField]
        Villager villager = null;

        Coroutine mActionCoroutine;//当前动作协程
        Coroutine mImportantActionCoroutine;//当前重要动作协程


        void OnEnable()
        {
            villager.Satiation = SATIATION_DEFAULT_VALUE;
            villager.Fatigue = FATIGUE_DEFAULT_VALUE;
            //数值初始化

            StartCoroutine(Tick());
        }

        IEnumerator Tick()//状态刷新循环
        {
            while (true)
            {
                villager.Satiation = Mathf.Max(0, villager.Satiation - Time.deltaTime);
                villager.Fatigue = Mathf.Max(0, villager.Fatigue - Time.deltaTime);

                if (villager.Satiation <= SATIATION_MIN_VALUE && mActionCoroutine == null)
                {
                    mActionCoroutine = StartCoroutine(EatFood());
                }

                if (villager.Fatigue <= FATIGUE_MIN_VALUE && mImportantActionCoroutine == null)
                {
                    if (mActionCoroutine != null)
                    {
                        StopCoroutine(mActionCoroutine);
                        mActionCoroutine = null;
                    }

                    mImportantActionCoroutine = StartCoroutine(Sleep());
                    mActionCoroutine = mImportantActionCoroutine;
                }

                yield return null;
            }
        }

        IEnumerator EatFood()//处理吃食物具体动作
        {
            Debug.Log("开始寻找食物!");

            yield return villager.Eat(() =>
            {
                Debug.Log("恢复饱食度!");
                villager.Satiation = SATIATION_DEFAULT_VALUE;
            });

            mActionCoroutine = null;
        }

        IEnumerator Sleep()//处理睡觉具体动作
        {
            Debug.Log("开始睡觉!");

            yield return villager.Sleep(() =>
            {
                Debug.Log("恢复精力!");
                villager.Fatigue = FATIGUE_DEFAULT_VALUE;
            });

            mActionCoroutine = null;
            mImportantActionCoroutine = null;
        }
    }
}
