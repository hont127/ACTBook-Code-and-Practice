﻿using System;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

namespace ACTBook
{
    [Serializable]
    [PostProcess(typeof(DistortFxRenderer), PostProcessEvent.AfterStack, "Custom/DistortFx")]
    //PostProcessEvent可指定该后处理特效位于默认后处理栈之前还是之后。
    public sealed class DistortFxSettings : PostProcessEffectSettings//Settings类通常存放字段信息
    {
        [Range(0f, 1f)]
        public FloatParameter intensityProp = new FloatParameter { value = 0.05f };//强度信息
    }

    public sealed class DistortFxRenderer : PostProcessEffectRenderer<DistortFxSettings>
    {
        Texture mNoiseTex;


        public override void Render(PostProcessRenderContext context)//实际渲染函数
        {
            var shader = Shader.Find("Hidden/ACTBook/Custom/DistortFxShader");
            var sheet = context.propertySheets.Get(shader);//可以取得缓存的材质属性块，若无缓存则创建
            sheet.properties.SetFloat("_Intensity", settings.intensityProp);//更新强度信息
            mNoiseTex = mNoiseTex ?? Resources.Load<Texture>("BlockNoiseTexture");//若噪声贴图缓存为空则加载
            sheet.properties.SetTexture("_NoiseTex", mNoiseTex);//更新噪声材质
            context.command.BlitFullscreenTriangle(context.source, context.destination, sheet, 0);//进行位块操作以应用屏幕Shader
        }
    }
}
