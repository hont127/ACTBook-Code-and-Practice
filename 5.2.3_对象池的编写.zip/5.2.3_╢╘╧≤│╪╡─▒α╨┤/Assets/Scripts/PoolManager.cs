﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class PoolManager
    {
        static PoolManager mInstance;
        public static PoolManager Instance { get { return mInstance ?? (mInstance = new PoolManager()); } }//单例
        List<DefaultPool> mPoolList;//池List

        public PoolManager()
        {
            mPoolList = new List<DefaultPool>();
        }
        public void RegistPool(DefaultPool pool)//注册池
        {
            mPoolList.Add(pool);
        }
        public void UnregistPool(DefaultPool pool)//反注册池
        {
            mPoolList.Remove(pool);
        }
        public DefaultPool GetPool(int id)//通过ID获取池
        {
            var result = default(DefaultPool);
            for (int i = 0, iMax = mPoolList.Count; i < iMax; i++)
            {
                var item = mPoolList[i];
                if (item.ID == id)
                {
                    result = item;
                    break;
                }
            }
            return result;
        }
        public void Prepare(int poolID, int poolSize)//重定义池缓存大小
        {
            GetPool(poolID).Prepare(poolSize);
        }
        public void ClearAll()//一般退出关卡时调用，清空所有池内对象
        {
            for (int i = 0, iMax = mPoolList.Count; i < iMax; i++)
                mPoolList[i].Clear();//执行池对象的清空函数
        }
    }
}
