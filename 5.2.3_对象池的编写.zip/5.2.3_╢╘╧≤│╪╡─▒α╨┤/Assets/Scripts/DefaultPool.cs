﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class DefaultPool
    {
        const string MSG_POOL_TAKE = "OnPoolTake";//池取出消息
        const string MSG_POOL_TAKE_BACK = "OnPoolTakeBack";//池放回消息
        bool mSendPoolMessage;//是否发送消息
        GameObject mTemplate;//模板
        protected Queue<GameObject> mMemberQueue;
        public int ID { get; private set; }//ID
        public int PoolSize { get; private set; }//池的的大小


        public DefaultPool(int id, GameObject template, bool sendPoolMessage = true)
        {
            ID = id;
            mTemplate = template;
            mSendPoolMessage = sendPoolMessage;
            mMemberQueue = new Queue<GameObject>();//初始化队列
        }

        public virtual GameObject TakeItem()//取出物品
        {
            if (mMemberQueue.Count == 0) return null;//默认是非增量逻辑
            var instanceGO = mMemberQueue.Dequeue();
            instanceGO.SetActive(true);
            if (mSendPoolMessage)
                instanceGO.BroadcastMessage(MSG_POOL_TAKE);
            return instanceGO;
        }

        public virtual void TakeBackItem(GameObject go)//放回物品
        {
            go.SetActive(false);
            if (mSendPoolMessage)
                go.BroadcastMessage(MSG_POOL_TAKE_BACK);
            mMemberQueue.Enqueue(go);
        }

        public virtual void Prepare(int poolSize)//重置池的大小
        {
            PoolSize = poolSize;
            Clear();//清空队列
            for (int i = 0; i < poolSize; i++)
            {
                var instancedGO = UnityEngine.Object.Instantiate(mTemplate, Vector3.zero, Quaternion.identity);
                instancedGO.SetActive(false);
                mMemberQueue.Enqueue(instancedGO);
            }//重新添加
        }

        public virtual void Clear()//清空池中所有对象
        {
            while (mMemberQueue.Count > 0)
                UnityEngine.Object.Destroy(mMemberQueue.Dequeue());
        }
    }
}
