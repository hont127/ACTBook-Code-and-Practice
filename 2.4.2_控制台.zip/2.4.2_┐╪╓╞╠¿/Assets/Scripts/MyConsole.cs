﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class MyConsole : MonoBehaviour
    {
        void OnEnable()
        {
            Application.logMessageReceived += LogMessageReceived;
            Application.logMessageReceivedThreaded += LogMessageReceivedThreaded;/*接收Log消息，包含不同线程。*/
        }

        void LogMessageReceived(string condition, string stackTrace, LogType type)
        {
            //do something...
        }

        void LogMessageReceivedThreaded(string condition, string stackTrace, LogType type)
        {
            //do something...
        }
    }
}
