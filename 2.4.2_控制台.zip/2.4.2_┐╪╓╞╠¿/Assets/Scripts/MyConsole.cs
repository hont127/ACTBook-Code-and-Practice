﻿using UnityEngine;

namespace ACTBook
{
    public class MyConsole : MonoBehaviour
    {
        string mRecvLogTestString;


        void OnEnable()
        {
            Application.logMessageReceived += LogMessageReceived;
            Application.logMessageReceivedThreaded += LogMessageReceivedThreaded;/*接收Log消息，包含不同线程。*/
        }

        void OnGUI()
        {
            GUILayout.Box("捕获日志:");
            GUILayout.Box(mRecvLogTestString);

            if (GUILayout.Button("发送测试Log"))
            {
                switch (Random.Range(0, 3))
                {
                    case 0:
                        Debug.Log("测试消息: " + Time.time);
                        break;

                    case 1:
                        Debug.LogWarning("测试消息: " + Time.time);
                        break;

                    case 2:
                        Debug.LogError("测试消息: " + Time.time);
                        break;

                    default:
                        break;
                }
            }

            if (GUILayout.Button("清空消息"))
            {
                mRecvLogTestString = "";
            }
        }

        void LogMessageReceived(string condition, string stackTrace, LogType type)
        {
            switch (type)
            {
                case LogType.Error:
                    mRecvLogTestString += "\n<color=#ff0000>[LogMessageReceived]condition: " + condition + " stackTrace: " + stackTrace + " logType: " + type + "</color>";
                    break;
                case LogType.Assert:
                    mRecvLogTestString += "\n<color=#ff0000>[LogMessageReceived]condition: " + condition + " stackTrace: " + stackTrace + " logType: " + type + "</color>";
                    break;
                case LogType.Warning:
                    mRecvLogTestString += "\n<color=#ffff00>[LogMessageReceived]condition: " + condition + " stackTrace: " + stackTrace + " logType: " + type + "</color>";
                    break;
                case LogType.Log:
                    mRecvLogTestString += "\n<color=#ffffff>[LogMessageReceived]condition: " + condition + " stackTrace: " + stackTrace + " logType: " + type + "</color>";
                    break;
                case LogType.Exception:
                    mRecvLogTestString += "\n<color=#ff0000>[LogMessageReceived]condition: " + condition + " stackTrace: " + stackTrace + " logType: " + type + "</color>";
                    break;
                default:
                    break;
            }

        }

        void LogMessageReceivedThreaded(string condition, string stackTrace, LogType type)
        {
        }
    }
}
