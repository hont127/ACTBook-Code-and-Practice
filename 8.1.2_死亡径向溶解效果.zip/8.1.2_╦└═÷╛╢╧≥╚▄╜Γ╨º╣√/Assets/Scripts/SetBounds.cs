﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class SetBounds : MonoBehaviour
    {
        public SkinnedMeshRenderer meshRenderer;//传入的网格渲染器

        void Start()
        {
            var bounds = meshRenderer.bounds;
            var boundsMin = bounds.min;
            meshRenderer.material.SetVector("_ModelBounds_Min", new Vector4(boundsMin.x, boundsMin.y, boundsMin.z));
            //将Bounds的Min传入当前实例材质球
            var boundsMax = bounds.max;
            meshRenderer.material.SetVector("_ModelBounds_Max", new Vector4(boundsMax.x, boundsMax.y, boundsMax.z));
            //将Bounds的Max传入当前实例材质球
        }
    }
}
