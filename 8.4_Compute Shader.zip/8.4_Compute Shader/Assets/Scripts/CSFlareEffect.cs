﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ACTBook
{
    public class CSFlareEffect : MonoBehaviour
    {
        const string CS_MAIN = "CSMain";
        const string SCREEN_TEX = "_ScreenTex";
        const string SCREEN_RW_TEX = "_ScreenRWTex";
        const string FLARE_TEX = "_FlareTex";
        const string SAMPLE_W = "sample_w";
        const string SAMPLE_H = "sample_h";
        const string FLARE_COMPUTE_SHADER_COUNT_FIELD = "_KeywordPointBuffer_Count";
        const string KEYWORD_POINT_BUFFER = "_KeywordPointBuffer";
        const int APPEND_KEYWORD_POINT_COUNT = 64;//最多64个特征点

        public ComputeShader collectionHightlightComputeShader;//高亮区域提取ComputeShader
        public ComputeShader flareComputeShader;//闪烁贴图绘制ComputeShader
        public Texture flareTex;//闪烁贴图
        public int hightlightSampleAmount = 8;//高亮区域采样量

        CommandBuffer mCachedCB;//缓存的CommandBuffer
        ComputeBuffer mAppendBuffer;//高光点缓存AppendBuffer
        ComputeBuffer mGetAppendCounterBuffer;//获取AppendBuffer最终数量的Counter Buffer
        ComputeBuffer mFlareBuffer;//闪烁绘制用到的关键点传入Buffer
        Vector3Int[] mKeywordScreenUvArray;//高光点Uv信息中间数组
        int[] mCounterCacheArray;//Counter缓存数组
        int mCollectionHightlightComputeKernelID;//高光区域提取ComputeShader的Kernel ID
        int mFlareComputeKernelID;//闪烁贴图绘制ComputeShader的Kernel ID
        int mAppendBuffer_ID;//字段ID
        int mScreenPixelWidth;//屏幕宽度
        int mScreenPixelHeight;//屏幕宽度

        void Start()
        {
            mCachedCB = new CommandBuffer();
            mKeywordScreenUvArray = new Vector3Int[APPEND_KEYWORD_POINT_COUNT];
            mCounterCacheArray = new int[1];//Counter只需要长度为1的数组拿到数据
            mAppendBuffer = new ComputeBuffer(APPEND_KEYWORD_POINT_COUNT, 4 * 3, ComputeBufferType.Append);
            //3个4字节的字段，最大长度是高光点缓存数量64
            mGetAppendCounterBuffer = new ComputeBuffer(1, sizeof(int), ComputeBufferType.IndirectArguments);
            mFlareBuffer = new ComputeBuffer(APPEND_KEYWORD_POINT_COUNT, 4 * 3);
            //用于高亮点传入的ComputeBuffer
            mCollectionHightlightComputeKernelID = collectionHightlightComputeShader.FindKernel(CS_MAIN);
            mFlareComputeKernelID = flareComputeShader.FindKernel(CS_MAIN);
            mAppendBuffer_ID = Shader.PropertyToID(KEYWORD_POINT_BUFFER);
            mScreenPixelWidth = Camera.main.pixelWidth;//屏幕宽度
            mScreenPixelHeight = Camera.main.pixelHeight;//屏幕高度
        }

        void OnDestroy()
        {
            mCachedCB.Release();
        }

        void OnRenderImage(RenderTexture source, RenderTexture destination)
        {
            var inRT = RenderTexture.GetTemporary(mScreenPixelWidth, mScreenPixelHeight, 0);
            inRT.filterMode = FilterMode.Point;
            var outRwRT = RenderTexture.GetTemporary(mScreenPixelWidth, mScreenPixelHeight, 0);
            outRwRT.filterMode = FilterMode.Point;
            outRwRT.enableRandomWrite = true;

            CollectionHightlightArea(source, inRT, outRwRT);//高光收集函数
            var flag = FlareTextureProcess(source, inRT, outRwRT);//星光绘制函数
            if (flag)//若有星光信息则使用outRwRT传递屏幕图像
                Graphics.Blit(outRwRT, destination);
            else//若没有星光信息则直接传递屏幕图像
                Graphics.Blit(source, destination);

            RenderTexture.ReleaseTemporary(inRT);
            RenderTexture.ReleaseTemporary(outRwRT);
        }

        void CollectionHightlightArea(RenderTexture screenSource, RenderTexture inRT, RenderTexture outRwRT)
        {
            mCachedCB.Clear();
            mCachedCB.SetRenderTarget(outRwRT);
            mCachedCB.ClearRenderTarget(true, true, Color.clear);//清空这张RT
            mAppendBuffer.SetCounterValue(0);//重置AppendBuffer
            mCachedCB.SetComputeBufferParam(collectionHightlightComputeShader, mCollectionHightlightComputeKernelID, mAppendBuffer_ID, mAppendBuffer);
            mCachedCB.Blit(screenSource, inRT);//屏幕图像拷贝到cbInTex
            mCachedCB.SetComputeTextureParam(collectionHightlightComputeShader, mCollectionHightlightComputeKernelID, SCREEN_TEX, inRT);
            mCachedCB.SetComputeTextureParam(collectionHightlightComputeShader, mCollectionHightlightComputeKernelID, SCREEN_RW_TEX, outRwRT);

            var ratio = mScreenPixelWidth / mScreenPixelHeight;
            var sample_w = hightlightSampleAmount * ratio;
            var sample_h = hightlightSampleAmount;
            mCachedCB.SetComputeIntParam(collectionHightlightComputeShader, SAMPLE_W, sample_w);
            mCachedCB.SetComputeIntParam(collectionHightlightComputeShader, SAMPLE_H, sample_h);
            mCachedCB.DispatchCompute(collectionHightlightComputeShader, mCollectionHightlightComputeKernelID, sample_w, sample_h, 1);
            Graphics.ExecuteCommandBuffer(mCachedCB);
        }

        bool FlareTextureProcess(RenderTexture screenSource, RenderTexture inRT, RenderTexture outRwRT)
        {
            ComputeBuffer.CopyCount(mAppendBuffer, mGetAppendCounterBuffer, 0);
            mGetAppendCounterBuffer.GetData(mCounterCacheArray);
            var currentKeywordScreenUvCount = mCounterCacheArray[0];
            mAppendBuffer.GetData(mKeywordScreenUvArray);
            mFlareBuffer.SetData(mKeywordScreenUvArray);

            if (currentKeywordScreenUvCount > 0)
            {
                mCachedCB.Clear();
                mCachedCB.Blit(screenSource, outRwRT);

                mCachedCB.SetComputeIntParam(flareComputeShader, FLARE_COMPUTE_SHADER_COUNT_FIELD, currentKeywordScreenUvCount);
                mCachedCB.SetComputeTextureParam(flareComputeShader, mFlareComputeKernelID, SCREEN_TEX, inRT);
                mCachedCB.SetComputeTextureParam(flareComputeShader, mFlareComputeKernelID, SCREEN_RW_TEX, outRwRT);
                mCachedCB.SetComputeTextureParam(flareComputeShader, mFlareComputeKernelID, FLARE_TEX, flareTex);
                mCachedCB.SetComputeBufferParam(flareComputeShader, mFlareComputeKernelID, KEYWORD_POINT_BUFFER, mFlareBuffer);
                mCachedCB.DispatchCompute(flareComputeShader, mFlareComputeKernelID, currentKeywordScreenUvCount, currentKeywordScreenUvCount, 1);
                Graphics.ExecuteCommandBuffer(mCachedCB);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
