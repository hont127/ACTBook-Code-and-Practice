﻿namespace ACTBook
{
    public interface ISceneComponent
    {
        int ID { get; }

        void Initialization(object interfaceObj);

        object GetHandler();

        void ForceExitComponent();
    }
}
