﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public static class SceneComponentConst
    {
        public const int LADDER = 1;//交互长梯
        public const int PUSHPULLBOX = 2;//推移箱子
    }
}
