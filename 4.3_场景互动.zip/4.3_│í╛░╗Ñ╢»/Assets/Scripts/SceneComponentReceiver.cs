﻿using System;
using System.Collections;
using UnityEngine;

namespace ACTBook
{
    public class SceneComponentReceiver : MonoBehaviour
    {
        const int SCENE_COMPONENT_MAX = 64;//最多64个组件
        BitArray mReceiveComponentIdentities;//筛选的位数组
        public string compareTag;//标签筛选
        public int[] receiveIdentities;//编辑面板配置接收ID
        public event Action<SceneComponentReceiver, ISceneComponent> OnReceived;//接收事件


        void Awake()
        {
            mReceiveComponentIdentities = new BitArray(SCENE_COMPONENT_MAX);//创建位数组
            for (int i = 0; i < receiveIdentities.Length; i++)
                mReceiveComponentIdentities[receiveIdentities[i]] = true;//接收ID都设为true
        }

        void OnTriggerEnter(Collider other)//碰撞事件触发
        {
            if (!other.CompareTag(compareTag)) return;//标签不一致跳出
            var sceneComponent = other.GetComponent<ISceneComponent>();
            if (mReceiveComponentIdentities[sceneComponent.ID])//进入筛选
            {
                if (OnReceived != null)
                    OnReceived(this, sceneComponent);//触发接收事件
            }
        }
    }
}
