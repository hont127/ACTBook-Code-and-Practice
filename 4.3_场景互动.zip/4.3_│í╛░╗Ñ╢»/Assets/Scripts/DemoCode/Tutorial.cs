﻿using UnityEngine;

public class Tutorial : MonoBehaviour
{
    void OnGUI()
    {
        GUILayout.Box("请拖动白色方块(测试玩家对象)，至小球的碰撞区域(测试梯子对象)内");
    }
}
