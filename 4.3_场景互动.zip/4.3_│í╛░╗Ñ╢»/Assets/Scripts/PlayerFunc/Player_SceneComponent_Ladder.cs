﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public partial class Player : MonoBehaviour, ILadderUser//玩家的部分类
    {
        void SceneComponent_Ladder_Initialization()//初始化函数，在主类里调用
        {
            sceneComponentReceiver.OnReceived += OnSceneComponentLadderReceived;//事件绑定
        }
        void SceneComponent_Ladder_Destroy()//销毁函数，在主类里调用
        {
            sceneComponentReceiver.OnReceived -= OnSceneComponentLadderReceived;//事件绑定注销
        }
        void OnSceneComponentLadderReceived(SceneComponentReceiver arg1, ISceneComponent arg2)
        {
            if (arg2.ID == SceneComponentConst.LADDER)//id判断
            {
                arg2.Initialization(this);//传入接口
                var ladderHandler = arg2.GetHandler() as ILadderHandler;

                //do something...
                Debug.Log("Ladder Component Process!");
            }
        }
        Transform ILadderUser.Transform { get { return transform; } }//user实现字段
        void ILadderUser.ToggleLadderAnimation(bool enable)//user实现函数
        {
            animator.SetBool("Ladder", enable);//动画变量修改
        }
    }
}
