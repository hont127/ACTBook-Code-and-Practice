﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public partial class Player : MonoBehaviour
    {
        public SceneComponentReceiver sceneComponentReceiver;
        public Animator animator;

        void OnEnable()
        {
            SceneComponent_Ladder_Initialization();
        }

        void OnDisable()
        {
            SceneComponent_Ladder_Destroy();
        }
    }
}
