﻿using UnityEngine;

namespace ACTBook
{
    public interface ILadderUser//使用角色需要实现它
    {
        Transform Transform { get; }

        void ToggleLadderAnimation(bool enable);//改变动画变量
    }

    public interface ILadderHandler
    {
        void MoveLeave();//用于AI,NPC直接调用爬梯子结束

        void MoveUp();//用于玩家，控制向上移动

        void MoveDown();//用于玩家，控制向下移动

    }

    class Ladder : MonoBehaviour, ISceneComponent, ILadderHandler
    {
        ILadderUser mLadderUser;
        int ISceneComponent.ID { get { return SceneComponentConst.LADDER; } }


        void ISceneComponent.Initialization(object interfaceObj)
        {
            mLadderUser = interfaceObj as ILadderUser;
            //do something...
        }
        void ISceneComponent.ForceExitComponent()
        {
            //do something...
        }
        object ISceneComponent.GetHandler()
        {
            return this;
        }
        void ILadderHandler.MoveLeave()
        {
            //do something...
        }
        void ILadderHandler.MoveUp()
        {
            //do something...
        }
        void ILadderHandler.MoveDown()
        {
            //do something...
        }
    }
}
