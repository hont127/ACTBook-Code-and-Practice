﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class PlayerFreezeTest : MonoBehaviour
    {
        public Cloth[] characterCloths;//角色的布料对象数组
        public Animator animator;
        public Rigidbody selfRigidbody;//角色刚体组件

        void Freeze(bool isFreeze)
        {
            if (isFreeze)//进入冻结逻辑
            {
                selfRigidbody.isKinematic = true;
                animator.enabled = false;
            }
            else//退出冻结逻辑
            {
                for (int i = 0; i < characterCloths.Length; i++)
                    characterCloths[i].ClearTransformMotion();//清空布料运动信息
                selfRigidbody.isKinematic = false;//恢复刚体
                animator.enabled = true;//恢复Animator
                animator.Rebind();//重置根运动
            }
        }
    }
}
