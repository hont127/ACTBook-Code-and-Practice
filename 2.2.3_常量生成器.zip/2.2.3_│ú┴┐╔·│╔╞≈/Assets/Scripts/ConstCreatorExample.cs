﻿using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class ConstCreatorExample : MonoBehaviour
    {
        [ContextMenu("Generate")]
        void Generate()
        {
            var sb = new StringBuilder();
            sb.AppendLine("public class _Const");
            sb.AppendLine("{");

            for (int i = 0; i < 32; i++)//遍历所有Layer
            {
                var name = LayerMask.LayerToName(i);

                name = name
                    .Replace(" ", "_")
                    .Replace("&", "_")
                    .Replace("/", "_")
                    .Replace(".", "_")
                    .Replace(",", "_")
                    .Replace(";", "_")
                    .Replace("-", "_");//对常见特殊字符进行过滤

                if (!string.IsNullOrEmpty(name))
                    sb.AppendFormat("\tpublic const int LAYER_{0} = {1};\n", name.ToUpper(), i);
            }
            sb.AppendLine("\tpublic const string " + ("Tag_Untagged".ToUpper() + " = " + "\"Untagged\";"));
            sb.AppendLine("\tpublic const string " + ("Tag_Respawn".ToUpper() + " = " + "\"Respawn\";"));
            sb.AppendLine("\tpublic const string " + ("Tag_Finish".ToUpper() + " = " + "\"Finish\";"));
            sb.AppendLine("\tpublic const string " + ("Tag_EditorOnly".ToUpper() + " = " + "\"EditorOnly\";"));
            sb.AppendLine("\tpublic const string " + ("Tag_MainCamera".ToUpper() + " = " + "\"MainCamera\";"));
            sb.AppendLine("\tpublic const string " + ("Tag_Player".ToUpper() + " = " + "\"Player\";"));
            sb.AppendLine("\tpublic const string " + ("Tag_GameController".ToUpper() + " = " + "\"GameController\";"));

            var asset = UnityEditor.AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset");//取得自定义Tag
            if ((asset != null) && (asset.Length > 0))
            {
                for (int i = 0; i < asset.Length; i++)
                {
                    var so = new UnityEditor.SerializedObject(asset[i]);
                    var tags = so.FindProperty("tags");

                    for (int j = 0; j < tags.arraySize; ++j)
                    {
                        var item = tags.GetArrayElementAtIndex(j).stringValue;
                        sb.AppendFormat("\tpublic const string TAG_{0} = \"{1}\";\n", item.ToUpper(), item);
                    }
                }
            }

            sb.AppendLine("}");

            File.WriteAllText("Assets/GeneratedConst.cs", sb.ToString());
            UnityEditor.AssetDatabase.Refresh();//通知unity刷新
        }
    }
}
