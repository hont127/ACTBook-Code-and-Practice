﻿using UnityEngine;

namespace ACTBook
{
    public class Tween1 : MonoBehaviour
    {
        const float TIME = 3f;
        const float DISTANCE = 3f;


        void Update()
        {
            var t = Mathf.Repeat(Time.time, TIME) / TIME;
            transform.localPosition = Vector3.Lerp(new Vector3(0f, 0f, 0f), new Vector3(DISTANCE, 0f, 0f), t);
        }
    }
}
