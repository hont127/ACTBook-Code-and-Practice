﻿using UnityEngine;

namespace ACTBook
{
    public class Tween3 : MonoBehaviour
    {
        const float TIME = 3f;
        const float DISTANCE = 3f;
        const float SMOOTH_TIME = 0.2f;

        Vector3 mVelocity;


        void Update()
        {
            var t = Mathf.Repeat(Time.time, TIME) / TIME;
            var quicken_t = t * t;
            transform.localPosition = Vector3.Lerp(new Vector3(0f, 0f, 0f), new Vector3(DISTANCE, 0f, 0f), quicken_t);
        }
    }
}
