﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public struct ComboCmd
    {
        const sbyte COUNTDOWN_INVALID = -1;//无效倒计时
        const sbyte STATE_SUCCESS = 1;//成功ID
        const sbyte STATE_FAILURE = -1;//失败ID
        const sbyte STATE_WAIT = 0;//等待ID

        float mLimitTime_Timer;//限制时间倒计时
        float mHoldTime_Timer;//长按时间倒计时
        public float LimitTime { get; set; }//限制时间
        public float HoldTime { get; set; }//长按时间
        public Func<bool> Conditional { get; set; }//检测条件(鼠标、键盘、手柄按下等)
        public Func<float> DeltaTime { get; set; }//两帧时间差

        public ComboCmd Reset()//重置
        {
            mLimitTime_Timer = LimitTime;
            mHoldTime_Timer = HoldTime;
            return this;
        }
        public ComboCmd Tick(out sbyte state)//每一次更新
        {
            state = STATE_WAIT;
            if (Conditional())//监测条件是否成立
            {
                if (mHoldTime_Timer > 0)//是否为长按
                    mHoldTime_Timer -= DeltaTime();
                else//不为长按且条件进入，则命令完成
                    state = STATE_SUCCESS;
            }
            if (state != STATE_SUCCESS && mLimitTime_Timer > COUNTDOWN_INVALID)//更新限制时间
            {
                mLimitTime_Timer -= DeltaTime();//更新倒计时
                if (mLimitTime_Timer <= 0)//超过时间则失败
                {
                    state = STATE_FAILURE;
                    mLimitTime_Timer = 0;
                }
            }
            return this;
        }
    }
}
