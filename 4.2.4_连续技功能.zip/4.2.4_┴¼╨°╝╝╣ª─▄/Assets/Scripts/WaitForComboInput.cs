﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class WaitForComboInput : IEnumerator
    {
        const sbyte COUNTDOWN_INVALID = -1;//无效倒计时
        const sbyte STATE_SUCCESS = 1;//成功ID
        const sbyte STATE_FAILURE = -1;//失败ID
        const sbyte STATE_WAIT = 0;//等待ID

        int mCurrentIndex;//当前指令索引
        ComboCmd[] mCmdArray;//指令数组
        public WaitForComboInput(ComboCmd[] comboCmdArray)//初始化
        {
            mCmdArray = comboCmdArray;
        }
        object IEnumerator.Current { get { return null; } }//接口实现
        void IEnumerator.Reset() { mCurrentIndex = 0; }//接口实现
        bool IEnumerator.MoveNext()//更新逻辑
        {
            var result = false;
            var state = STATE_FAILURE;//初始化状态
            mCmdArray[mCurrentIndex] = mCmdArray[mCurrentIndex].Tick(out state);//更新命令
            switch (state)
            {
                case STATE_FAILURE://失败的情况
                    mCurrentIndex = 0;
                    for (int i = 0, iMax = mCmdArray.Length; i < iMax; i++)
                        mCmdArray[i] = mCmdArray[i].Reset();//失败重置
                    result = true;
                    break;
                case STATE_SUCCESS://成功的情况
                    mCurrentIndex++;
                    if (mCurrentIndex == mCmdArray.Length)
                        result = false;//若为最后一个指令协程结束
                    else
                        result = true;
                    break;
                case STATE_WAIT://继续等待
                    result = true;
                    break;
            }
            return result;//若返回值为True则继续更新
        }
    }
}