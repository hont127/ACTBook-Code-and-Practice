﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    class Foo : MonoBehaviour
    {
        IEnumerator Start()
        {
            Func<float> deltaTime = () => Time.deltaTime;//时间间隔函数
            yield return new WaitForComboInput(new ComboCmd[]
            {
            new ComboCmd(){Conditional=()=>Input.GetKey(KeyCode.X), DeltaTime=deltaTime, HoldTime=-1, LimitTime=0.2f },//0.2秒内按下x
            new ComboCmd(){Conditional=()=>Input.GetKey(KeyCode.Y), DeltaTime=deltaTime, HoldTime=-1, LimitTime=0.2f },//0.2秒内按下y
            new ComboCmd(){Conditional=()=>Input.GetKey(KeyCode.A) && Input.GetKey(KeyCode.B), DeltaTime=deltaTime, HoldTime=-1, LimitTime=0.2f },//0.2秒内按下a,b
            });
            Debug.Log("Triggered!");//触发
        }
    }
}
