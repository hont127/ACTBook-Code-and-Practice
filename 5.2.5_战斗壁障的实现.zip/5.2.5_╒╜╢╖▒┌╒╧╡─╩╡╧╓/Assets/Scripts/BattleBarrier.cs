﻿using UnityEngine;

namespace ACTBook
{
    public class BattleBarrier : MonoBehaviour
    {
        public SpawnPoint[] listenSpawnPoints;//监听的SpawnPoint
        public BattleBarrierPlane[] barrierPlanes;//战斗壁障平面
        bool mIsTrigger;//触发状态标记


        void Update()
        {
            if (!mIsTrigger) return;
            var flag = true;
            for (int i = 0; i < listenSpawnPoints.Length; i++)
            {
                if (listenSpawnPoints[i].SpawnedGO != null)
                {
                    flag = false;
                    break;
                }
            }//检测怪物是否全部死亡
            if (flag)
            {
                for (int i = 0; i < barrierPlanes.Length; i++)
                    barrierPlanes[i].Fade();//壁障平面淡出
                enabled = false;//关闭脚本自身
            }
        }

        void OnTriggerEnter(Collider other)
        {
            const string PLAYER = "Player";
            if (!other.CompareTag(PLAYER)) return;//非玩家触发则跳出
            if (mIsTrigger) return;
            for (int i = 0; i < barrierPlanes.Length; i++)//触发壁障显示
                barrierPlanes[i].Show();
            mIsTrigger = true;
        }
    }
}
