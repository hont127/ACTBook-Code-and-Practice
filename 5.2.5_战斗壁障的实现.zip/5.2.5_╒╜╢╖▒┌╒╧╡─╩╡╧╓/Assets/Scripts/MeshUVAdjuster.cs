﻿using UnityEngine;

namespace ACTBook
{
    public class MeshUVAdjuster : MonoBehaviour
    {
        const float MAX_X_SCALE = 5f;

        public MeshFilter meshFilter;
        Mesh mCacheMesh;
        Vector2[] mCacheUvArray;


        void OnEnable()
        {
            MeshScaleCache();
        }

        void Update()
        {
            MeshScaleUpdate();
        }

        void MeshScaleCache()//缓存初始UV
        {
            mCacheMesh = meshFilter.mesh;
            var meshUv = mCacheMesh.uv;
            mCacheUvArray = new Vector2[meshUv.Length];
            for (int i = 0; i < meshUv.Length; i++)
                mCacheUvArray[i] = meshUv[i];
        }

        void MeshScaleUpdate()//将UV按照缩放值赋予相应比例
        {
            var scaleRatio = transform.lossyScale.x / MAX_X_SCALE;
            var uv = mCacheMesh.uv;
            for (int i = 0; i < uv.Length; i++)
                uv[i].x = mCacheUvArray[i].x * scaleRatio;
            mCacheMesh.uv = uv;
        }
    }
}