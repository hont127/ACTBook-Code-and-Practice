﻿using UnityEngine;

public class Tutorial : MonoBehaviour
{
    void OnGUI()
    {
        GUILayout.Box("案例测试方式：" +
            "\n拖动缩放轴，缩放BattleBarrierPlane对象" +
            "\n会发现对象上的纹理并不会随着缩放而拉伸" +
            "\n这样可以在任意大小的关口处放置，避免了拉伸问题"
            + "\n"
            + "\n"
            + "\n删除EnemySpawnPoint1和EnemySpawnPoint2内的TestEnemy(Clone)对象"
            +"\n以模拟敌人死亡(若为池的形式可以在SpawnPoint内继续扩展修改)"
            + "\n此时壁障消失，案例测试完成。");
    }
}
