﻿using UnityEngine;

namespace ACTBook
{
    public class BattleBarrierPlane : MonoBehaviour
    {
        public MeshRenderer meshRenderer;


        public void Show()
        {
            meshRenderer.enabled = true;
            Debug.Log("敌人出现!壁障触发!");
        }

        public void Fade()
        {
            meshRenderer.enabled = false;
            Debug.Log("敌人死亡!壁障消失!");
        }
    }
}