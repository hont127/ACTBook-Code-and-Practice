﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class BattleBarrierPlane : MonoBehaviour
    {
        public void Show()
        {
        }
        public void Fade()
        {
        }
    }
}