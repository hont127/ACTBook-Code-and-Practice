﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;

namespace ACTBook
{
    [CustomEditor(typeof(SpawnPoint))]
    [CanEditMultipleObjects]
    public class SpawnPointInspector : Editor
    {
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();

            GUILayout.BeginVertical(GUI.skin.box);

            if (GUILayout.Button("Preview"))
            {
                var spawnPoint = base.target as SpawnPoint;//拿到SpawnPoint具体对象
                var cacheResourceLocation = spawnPoint.resourceLocation;//只支持调试Resources目标的对象
                                                                        //但也可以将调试路径填入Resources字段供编辑器内调试使用。
                spawnPoint.resourceLocation = SpawnPoint.EResourcesLocation.Resources;
                spawnPoint.GetType().GetMethod("Spawn", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(spawnPoint, null);
                //通过反射调用Spawn方法。
                if (spawnPoint.SpawnedGO != null)
                    spawnPoint.SpawnedGO.hideFlags = HideFlags.DontSaveInEditor | HideFlags.NotEditable;
                //创建出来的对象标记为不可保存不可编辑状态
                spawnPoint.resourceLocation = cacheResourceLocation;//恢复实例源
            }

            if (GUILayout.Button("Clear Preview"))
            {
                var spawnPoint = base.target as SpawnPoint;//拿到SpawnPoint具体对象
                if (spawnPoint.SpawnedGO != null)//是否已经创建了对象
                    DestroyImmediate(spawnPoint.SpawnedGO);//直接将已创建的对象销毁
            }

            GUILayout.EndVertical();
        }
    }
}
