﻿using UnityEngine;
using System;

namespace ACTBook
{
    public class SpawnPoint : MonoBehaviour
    {
        public enum EHierarchyMode { Child, EqulsParent }//层级模式枚举
        public enum EResourcesLocation { AssetBundle, Resources }//实例源位置枚举
        public enum ESpawnOrder { None, Manual, OnEnabled, Start, Message }//时序枚举
        public string resourcePath;//Resource路径
        public ESpawnOrder spawnOrder;//实例化时序
        public EResourcesLocation resourceLocation;//实例化源
        public EHierarchyMode createHierMode;//层级模式
        GameObject mSpawnedGO;//已创建的对象缓存

        public GameObject SpawnedGO { get { return mSpawnedGO; } }//已创建的对象实例
        public bool IsSpawned { get { return SpawnedGO != null; } }//是否已创建
        public event Action<GameObject> OnSpawned;//创建回调


        protected virtual void OnEnable()//OnEnable事件
        {
            if (spawnOrder != ESpawnOrder.OnEnabled) return;//时序检测
            Spawn();//创建
        }

        protected virtual void Start()//Start事件
        {
            if (spawnOrder != ESpawnOrder.Start) return;//时序检测
            Spawn();//创建
        }

        protected virtual void OnDestroy()//OnDestroy事件
        {
            Recycle();//执行回收
        }

        //尝试创建，若已创建则跳出
        public virtual bool TrySpawn()
        {
            if (IsSpawned) return false;//跳出逻辑
            Spawn();//创建
            return true;
        }
        //处理回收的逻辑
        //未来加入池的话这里还会增加一些内容。

        public virtual void Recycle()
        {
            mSpawnedGO = null;
        }

        protected virtual void Spawn()
        {
            var instancedGO = default(GameObject);
            switch (resourceLocation)//开始从特定源实例数据
            {
                case EResourcesLocation.AssetBundle://AB包需要自己实现一些内容
                                                    //AssetBundleManager do something...
                    break;
                case EResourcesLocation.Resources://Resource直接Load进来然后实例化
                    var resHandle = Resources.Load<GameObject>(resourcePath);
                    instancedGO = Instantiate(resHandle) as GameObject;//实例化
                    instancedGO.name.Substring(0, instancedGO.name.Length - "(Clone)".Length);//删除Cloneh后缀
                    break;
            }
            if (instancedGO == null)//检测创建失败情况，多数时为面板路径填错
                Debug.LogError("实例化失败！请检查面板填写是否正确!");
            switch (createHierMode)//层级模式
            {
                case EHierarchyMode.Child://创建为SpawnPoint的子对象
                    instancedGO.transform.parent = transform;
                    instancedGO.transform.localPosition = Vector3.zero;
                    instancedGO.transform.localRotation = Quaternion.identity;
                    break;
                case EHierarchyMode.EqulsParent://与SpawnPoint一致的父级
                    instancedGO.transform.parent = transform.parent;
                    instancedGO.transform.position = transform.position;
                    instancedGO.transform.rotation = transform.rotation;
                    break;
            }
            mSpawnedGO = instancedGO;//赋值到内部字段
            if (OnSpawned != null)//触发回调
                OnSpawned(mSpawnedGO);
        }
    }
}
