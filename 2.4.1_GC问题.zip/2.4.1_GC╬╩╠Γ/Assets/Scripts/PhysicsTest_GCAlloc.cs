﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class PhysicsTest_GCAlloc : MonoBehaviour
    {
        void Update()
        {
            var hits = Physics.RaycastAll(new Ray(Vector3.zero, Vector3.forward), 5f);
            for (int i = 0; i < hits.Length; i++)
            {
                //do something...
            }
        }
    }
}
