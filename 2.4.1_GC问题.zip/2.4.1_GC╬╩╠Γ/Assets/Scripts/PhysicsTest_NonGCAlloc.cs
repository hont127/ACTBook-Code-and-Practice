﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class PhysicsTest_NonGCAlloc : MonoBehaviour
    {
        RaycastHit[] mCacheHits;

        void Start()
        {
            mCacheHits = new RaycastHit[100];//缓存100个hit结果.
        }

        void Update()
        {
            var hitsCount = Physics.RaycastNonAlloc(new Ray(Vector3.zero, Vector3.forward), mCacheHits, 5f);
            for (int i = 0; i < hitsCount; i++)
            {
                var hit = mCacheHits[i];
                //do something...
            }
        }
    }
}
