﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class MessageManagerTest : MonoBehaviour
    {
        void OnGUI()
        {
            if (GUILayout.Button("Subscribe"))
            {
                MessageManager.Instance.Subscribe("my_message", MyMessageCallback);
            }

            if (GUILayout.Button("Unsubscribe"))
            {
                MessageManager.Instance.Unsubscribe("my_message");
            }

            if (GUILayout.Button("Process Dispatch Cache"))
            {
                MessageManager.Instance.ProcessDispatchCache("my_message");
            }

            if (GUILayout.Button("Dispatch"))
            {
                MessageManager.Instance.Dispatch("my_message");
            }

            if (GUILayout.Button("Dispatch(cache)"))
            {
                MessageManager.Instance.Dispatch("my_message", null, true);
            }
        }

        void MyMessageCallback(object[] args)
        {
            Debug.Log("message! " + args);
        }
    }
}
