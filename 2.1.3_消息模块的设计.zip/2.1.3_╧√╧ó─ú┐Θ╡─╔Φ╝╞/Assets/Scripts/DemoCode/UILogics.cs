﻿using UnityEngine;
using UnityEngine.UI;

namespace ACTBook
{
    /// <summary>
    /// 此为测试UI脚本，主要演示消息模块的简单使用。
    /// </summary>
    public class UILogics : MonoBehaviour
    {
        const string MSG_BATTLE_PRIZE_TEST = "BattlePrizeTest";

        [SerializeField]
        Text bagLogText = null;

        [SerializeField]
        Button sendBattleTestButton = null;

        [SerializeField]
        Button bagButton = null;

        [SerializeField]
        Button clearBagPrizeButton = null;

        [SerializeField]
        Button combatButton = null;

        [SerializeField]
        GameObject combatPanelGO = null;

        [SerializeField]
        Button combatCloseButton = null;

        [SerializeField]
        GameObject bagPanelGO = null;

        [SerializeField]
        Button bagCloseButton = null;

        [SerializeField]
        Image bagBtnRedPointTips = null;


        void Awake()
        {
            clearBagPrizeButton.onClick.AddListener(OnClearBagPrizeButtonClickedCallback);

            bagButton.onClick.AddListener(OnBagButtonClickedCallback);
            combatButton.onClick.AddListener(OnCombatButtonClickedCallback);

            bagCloseButton.onClick.AddListener(OnBagCloseButtonClickedCallback);
            combatCloseButton.onClick.AddListener(OnCombatCloseButtonClickedCallback);

            sendBattleTestButton.onClick.AddListener(OnSendBattleTestButtonClickedCallback);

            MessageManager.Instance.Subscribe(MSG_BATTLE_PRIZE_TEST, OnBattlePrizeMessage);//在初始化时订阅消息
        }

        void OnBattlePrizeMessage(object[] args)
        {
            var prizeCount = args[0];
            bagLogText.text = "当前获得战利品: " + prizeCount + " 个";

            bagBtnRedPointTips.gameObject.SetActive(true);
        }

        void OnBagButtonClickedCallback()
        {
            bagPanelGO.SetActive(true);
            bagBtnRedPointTips.gameObject.SetActive(false);

            MessageManager.Instance.RemoveFromMessageCache(MSG_BATTLE_PRIZE_TEST);//用户已阅读过内容了，移除缓存的消息
        }

        void OnCombatButtonClickedCallback()
        {
            combatPanelGO.SetActive(true);
        }

        void OnBagCloseButtonClickedCallback()
        {
            bagPanelGO.SetActive(false);
            OnBackToHall();
        }

        void OnCombatCloseButtonClickedCallback()
        {
            combatPanelGO.SetActive(false);
            OnBackToHall();
        }

        void OnClearBagPrizeButtonClickedCallback()
        {
            bagLogText.text = "";
        }

        void OnSendBattleTestButtonClickedCallback()
        {
            var prizeContents = Random.Range(0, 24);//获得的战利品数量
            MessageManager.Instance.Dispatch(MSG_BATTLE_PRIZE_TEST, new object[] { prizeContents }, true);
            //分发获得战利品消息
        }

        //回到大厅时调用该函数
        void OnBackToHall()
        {
            MessageManager.Instance.PullMessageCache(MSG_BATTLE_PRIZE_TEST, false);
            //拉取缓存的战利品消息
        }
    }
}
