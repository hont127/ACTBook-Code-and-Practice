﻿using UnityEngine;

namespace ACTBook
{
    public class MessageManagerTest : MonoBehaviour
    {
        void OnGUI()
        {
            if (GUILayout.Button("Subscribe"))//订阅消息
            {
                MessageManager.Instance.Subscribe("my_message", MyMessageCallback);
            }

            if (GUILayout.Button("Unsubscribe"))//取消消息订阅
            {
                MessageManager.Instance.Unsubscribe("my_message");
            }

            if (GUILayout.Button("Process Dispatch Cache"))//处理分发缓存
            {
                MessageManager.Instance.PullMessageCache("my_message");
            }

            if (GUILayout.Button("Dispatch"))//分发消息(此时订阅了该消息的函数会被触发)
            {
                MessageManager.Instance.Dispatch("my_message");
            }

            if (GUILayout.Button("Dispatch(cache)"))//分发消息，但不立即触发，而是添加到缓存
            {
                MessageManager.Instance.Dispatch("my_message", null, true);
            }
        }

        void MyMessageCallback(object[] args)
        {
            Debug.Log("message! " + args);
        }//订阅消息的测试方法
    }
}
