﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

namespace ACTBook
{
    public class AudioManager : MonoBehaviour
    {
        static bool mIsDestroying;
        static AudioManager mInstance;
        public static AudioManager Instance
        {
            get
            {
                if (mIsDestroying) return null;
                if (mInstance == null)
                {
                    mInstance = new GameObject("[AudioManager]").AddComponent<AudioManager>();
                    DontDestroyOnLoad(mInstance.gameObject);
                }
                return mInstance;
            }
        }//mono单例

        const string BACKGROUNDMUSIC_TEMPLATE_RES_PATH = "Audio/BackgroundMusic";//背景音乐初始化路径常量
        const string SOUNDFX_TEMPLATE_RES_PATH = "Audio/SoundFX";//音效初始化路径常量

        SoundFXController mSoundFXController;
        BackgroundMusicController mBackgroundMusicController;


        public void RegistToBackgroundMusicTemplate(AudioSource audioSource)
        {
            mBackgroundMusicController.RegistToTemplate(audioSource);
        }

        public void RegistToSoundFXTemplate(SoundFXData soundFxData)
        {
            mSoundFXController.RegistToTemplate(soundFxData);
        }

        public void PlayBackgroundMusic(string name)//播放目标背景音乐
        {
            mBackgroundMusicController.PlayMusic(name);
        }

        public void StopBackgroundMusic()//停止当前背景音乐
        {
            mBackgroundMusicController.Stop();
        }

        public AudioSource PlaySFX(string name, AudioMixerGroup audioMixerGroup = null, Vector3? point = null)
        {
            return mSoundFXController.PlaySFX(name, audioMixerGroup, point);
        }

        public void StopAllSFX()
        {
            mSoundFXController.StopAllSFX();
        }

        public void Initialization()//初始化时自动通过常量路径进行加载
        {
            if (!string.IsNullOrEmpty(BACKGROUNDMUSIC_TEMPLATE_RES_PATH))
            {
                var resAudioClipArray = Resources.LoadAll<AudioClip>(BACKGROUNDMUSIC_TEMPLATE_RES_PATH);
                foreach (var item in resAudioClipArray)
                {
                    var go = new GameObject(item.name);
                    go.transform.parent = transform;
                    var audioSource = go.AddComponent<AudioSource>();
                    audioSource.clip = item;
                    audioSource.loop = true;
                    audioSource.playOnAwake = false;
                    RegistToBackgroundMusicTemplate(audioSource);//注意这里是被省略的转发函数
                }
            }
            if (!string.IsNullOrEmpty(SOUNDFX_TEMPLATE_RES_PATH))
            {
                var resAudioClipArray = Resources.LoadAll<SoundFXData>(SOUNDFX_TEMPLATE_RES_PATH);
                for (int i = 0; i < resAudioClipArray.Length; i++)
                {
                    var item = resAudioClipArray[i];
                    var go = new GameObject(item.name);
                    go.transform.parent = transform;
                    var audioSource = go.AddComponent<AudioSource>();
                    audioSource.clip = item.audioClip;
                    audioSource.playOnAwake = false;
                    audioSource.spatialBlend = 0;//2D
                    var sfxData = Instantiate(item);
                    sfxData.audioSource = audioSource;
                    RegistToSoundFXTemplate(sfxData);
                }
            }
        }

        void Awake()
        {
            mSoundFXController = new SoundFXController();
            mBackgroundMusicController = new BackgroundMusicController();
        }

        void Update()//更新绑定
        {
            mSoundFXController.Update();
            mBackgroundMusicController.Update();
        }

        void OnDestroy()
        {
            mIsDestroying = true;
        }
    }
}
