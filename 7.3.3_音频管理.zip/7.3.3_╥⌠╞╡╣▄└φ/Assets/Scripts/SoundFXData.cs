﻿using UnityEngine;

namespace ACTBook
{
    [CreateAssetMenu(fileName = "SoundFXData.asset", menuName = "SoundFXData")]
    public class SoundFXData : ScriptableObject
    {
        [Range(0f, 1f)] public float volume = 1f;//音量
        public float offset;//偏移
        public AudioClip audioClip;//剪辑对象链接
        [HideInInspector] public float birthFrame;//创建帧
        [HideInInspector] public AudioSource audioSource;//音源对象
        [HideInInspector] public float lifeTimer;//销毁倒计时
    }
}
