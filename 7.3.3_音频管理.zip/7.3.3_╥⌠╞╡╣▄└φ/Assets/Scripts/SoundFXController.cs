﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

namespace ACTBook
{
    public class SoundFXController
    {
        const float MAX_VOLUME = 1f;//音量最大值
        List<SoundFXData> mCurrentSoundFXList;//当前正播放的音效列表
        List<SoundFXData> mTemplateList;//音效模板列表
        public float Volume { get; set; }//整体音量
        public List<SoundFXData> CurrentSoundFXList { get { return mCurrentSoundFXList; } }//当前音效
        public List<SoundFXData> TemplateList { get { return mTemplateList; } }//模板列表


        public SoundFXController()
        {
            Volume = MAX_VOLUME;
            mCurrentSoundFXList = new List<SoundFXData>();
            mTemplateList = new List<SoundFXData>();
        }

        public void RegistToTemplate(SoundFXData template)//音效模板注册
        {
            mTemplateList.Add(template);
        }

        public void UnregistFromTemplate(SoundFXData template)//音效模板反注册
        {
            mTemplateList.Remove(template);
        }

        public void StopAllSFX()//停止所有音效
        {
            for (int i = mCurrentSoundFXList.Count - 1; i >= 0; i--)
                DestroySFX(mCurrentSoundFXList[i]);
        }

        public void Update()//销毁及Volume更新逻辑
        {
            for (int i = mCurrentSoundFXList.Count - 1; i >= 0; i--)
            {
                var item = mCurrentSoundFXList[i];
                item.lifeTimer -= Time.deltaTime;
                if (item.lifeTimer <= 0f) DestroySFX(item);
                else item.audioSource.volume = item.volume * Volume;
            }
        }

        public AudioSource PlaySFX(string name, AudioMixerGroup audioMixerGroup = null, Vector3? point = null)
        {
            if (Volume <= 0) return null;//音量设定为0则跳出播放
            var targetSFXTemplate = mTemplateList.Find(m => m.audioSource.name == name);
            if (targetSFXTemplate == null) Debug.LogError("无法获取要播放的音频:" + name);
            for (int i = 0, iMax = mCurrentSoundFXList.Count; i < iMax; i++)
            {
                if (mCurrentSoundFXList[i].audioSource.name == name
                   && mCurrentSoundFXList[i].birthFrame == Time.frameCount)
                    return null;
            }//避免同一帧播放多个同样音效，会导致声音被放大
            return PlaySFX(targetSFXTemplate, audioMixerGroup, point);
        }

        AudioSource PlaySFX(SoundFXData templateData, AudioMixerGroup audioMixerGroup, Vector3? point = null)
        {
            var instancedSFX = UnityEngine.Object.Instantiate(templateData.audioSource.gameObject);
            instancedSFX.gameObject.SetActive(true);//从模板实例化
            var targetAudioSource = instancedSFX.GetComponent<AudioSource>();
            targetAudioSource.outputAudioMixerGroup = audioMixerGroup;
            if (point != null)//若是3D音效则设置位置
                instancedSFX.transform.position = point.Value;
            if (templateData.offset > 0)
            {
                targetAudioSource.PlayDelayed(templateData.offset);
            }
            else
            {
                targetAudioSource.time = -templateData.offset;
                targetAudioSource.Play();
            }//偏移的逻辑处理
            targetAudioSource.volume = templateData.volume * Volume;
            var soundFXData = ScriptableObject.CreateInstance<SoundFXData>();
            soundFXData.audioSource = targetAudioSource;
            soundFXData.lifeTimer = templateData.audioClip.length;
            mCurrentSoundFXList.Add(soundFXData);//音效对象加入列表
            return targetAudioSource;
        }

        void DestroySFX(SoundFXData soundFXData)//销毁音效处理
        {
            mCurrentSoundFXList.Remove(soundFXData);
            UnityEngine.Object.Destroy(soundFXData.audioSource.gameObject);
        }
    }
}
