﻿using UnityEngine;

namespace ACTBook
{
    public class AudioManager_Test : MonoBehaviour
    {
        void OnGUI()
        {
            if (GUILayout.Button("Audio Manager Init"))
            {
                AudioManager.Instance.Initialization();
            }

            if (GUILayout.Button("Play Test BGM"))
            {
                AudioManager.Instance.PlayBackgroundMusic("TestBGM");
            }

            if (GUILayout.Button("Stop BGM"))
            {
                AudioManager.Instance.StopBackgroundMusic();
            }

            if (GUILayout.Button("Play Test SFX"))
            {
                AudioManager.Instance.PlaySFX("TestSFX");
            }

            if (GUILayout.Button("Stop All SFX"))
            {
                AudioManager.Instance.StopAllSFX();
            }
        }
    }
}
