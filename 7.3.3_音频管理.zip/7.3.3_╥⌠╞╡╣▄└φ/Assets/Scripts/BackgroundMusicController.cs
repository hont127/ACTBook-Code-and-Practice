﻿using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class BackgroundMusicController
    {
        const float MAX_VOLUME = 1f;//音量最大值

        List<AudioSource> mTemplateList;//模板列表
        AudioSource mCurrentAudioSource;
        public AudioSource CurrentAudioSource { get { return mCurrentAudioSource; } }//当前音源，用于外部直接修改
        public List<AudioSource> TemplateList { get { return mTemplateList; } }//模板列表
        public float Volume { get; set; }//背景音乐整体音量


        public BackgroundMusicController()
        {
            mTemplateList = new List<AudioSource>();
            Volume = MAX_VOLUME;
        }

        public void RegistToTemplate(AudioSource audioSource)//注册到模板
        {
            mTemplateList.Add(audioSource);
        }

        public void UnregistFromTemplate(AudioSource audioSource)//反注册模板
        {
            mTemplateList.Remove(audioSource);
        }

        public void Update()//更新逻辑
        {
            if (mCurrentAudioSource != null) mCurrentAudioSource.volume = Volume;
        }

        public AudioSource FindAudioSourceFromTemplate(string name)//获取某个已注册的音源
        {
            var result = default(AudioSource);
            for (int i = 0, iMax = mTemplateList.Count; i < iMax; i++)
            {
                if (mTemplateList[i].name == name)//名称比较
                {
                    result = mTemplateList[i];
                    break;
                }
            }
            if (result == null) throw new System.Exception("无法获取要播放的音频:" + name);
            return result;
        }

        public void PlayMusic(string name)//播放目标背景音乐
        {
            Stop();//先尝试停止正在播放的背景音乐
            mCurrentAudioSource = FindAudioSourceFromTemplate(name);
            mCurrentAudioSource.volume = Volume;//赋予音量
            mCurrentAudioSource.Play();
        }

        public void Stop()//停止当前背景音乐
        {
            if (mCurrentAudioSource != null) mCurrentAudioSource.Stop();
            mCurrentAudioSource = null;
        }
    }
}
