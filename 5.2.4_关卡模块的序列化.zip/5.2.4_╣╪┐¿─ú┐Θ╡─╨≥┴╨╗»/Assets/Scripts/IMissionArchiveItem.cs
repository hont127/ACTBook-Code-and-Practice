﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace ACTBook
{
    public interface IMissionArchiveItem : IGuidObject
    {
        void OnSerialize(BinaryWriter writer);//序列化
        void OnMissionArchiveInitialization(BinaryReader reader, bool hasSerializeData);//关卡初始化
    }
}