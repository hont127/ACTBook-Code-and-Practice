﻿using System.IO;
using UnityEngine;

namespace ACTBook
{
    public class SerializeTest : MonoBehaviour
    {
        byte[] mBytes;


        void OnGUI()
        {
            GUILayout.Box("测试方式:\n首先修改一下Foo脚本上的Hp字段，例如修改为50" +
                "\n然后点击Serialize Scene，此时场景已经被储存" +
                "\n再次修改Foo脚本上的Hp字段，例如修改为80。随后点击Deserialize Scene" +
                "\n可以看见值回到了50，则反序列化成功。");

            if (GUILayout.Button("Serialize Scene(序列化场景/储存场景)"))
            {
                using (var memoryStream = new MemoryStream())
                {
                    MissionArchiveManager.Instance.MissionSerialize(memoryStream);
                    mBytes = memoryStream.ToArray();
                }
            }

            if (GUILayout.Button("Deserialize Scene(反序列化场景/加载场景)"))
            {
                using (var memoryStream = new MemoryStream(mBytes))
                {
                    MissionArchiveManager.Instance.MissionInitialization(memoryStream);
                }
            }
        }
    }
}
