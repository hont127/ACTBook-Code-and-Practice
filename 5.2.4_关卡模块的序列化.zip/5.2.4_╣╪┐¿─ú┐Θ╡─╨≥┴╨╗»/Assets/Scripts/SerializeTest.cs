﻿using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class SerializeTest : MonoBehaviour
    {
        byte[] mBytes;


        void OnGUI()
        {
            if (GUILayout.Button("Serialize Scene"))
            {
                using (var memoryStream = new MemoryStream())
                {
                    MissionArchiveManager.Instance.MissionSerialize(memoryStream);
                    mBytes = memoryStream.ToArray();
                }
            }

            if (GUILayout.Button("Deserialize Scene"))
            {
                using (var memoryStream = new MemoryStream(mBytes))
                {
                    MissionArchiveManager.Instance.MissionInitialization(memoryStream);
                }
            }
        }
    }
}
