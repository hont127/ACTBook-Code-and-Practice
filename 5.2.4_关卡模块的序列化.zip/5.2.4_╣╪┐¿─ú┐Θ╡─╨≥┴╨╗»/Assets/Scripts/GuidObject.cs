﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class GuidObject : MonoBehaviour, IGuidObject
    {
        static long mRuntimeGuidCounter = long.MinValue;//动态对象的GUID计数变量
        public long guid;
#if UNITY_EDITOR
        public bool lockedGuid;//锁定GUID值
#endif
        long IGuidObject.Guid { get { return guid; } }//接口实现
        public void ArrangeRuntimeGuid()//动态对象初始化GUID
        {
            mRuntimeGuidCounter++;
            guid = mRuntimeGuidCounter;
        }
#if UNITY_EDITOR
        protected virtual void OnValidate()
        {
            if (!lockedGuid)
                guid = CreateLongGUID();
        }
#endif

        long CreateLongGUID()
        {
            var buffer = System.Guid.NewGuid().ToByteArray();//创建GUID字节数组
            return System.BitConverter.ToInt64(buffer, 0);//转换为long类型
        }
    }
}
