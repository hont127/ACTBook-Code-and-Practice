﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace ACTBook
{
    public class Foo : GuidObject, IMissionArchiveItem
    {
        public int hp;//生命值，此处便于调试将字段直接暴露

        void Awake()
        {
            MissionArchiveManager.Instance.RegistMissionArchiveItem(this);//注册关卡组件
        }

        void OnDestroy()
        {
            MissionArchiveManager.Instance.UnregistMissionArchiveItem(this);//反注册关卡组件
        }

        void IMissionArchiveItem.OnMissionArchiveInitialization(BinaryReader deserialize, bool hasSerializeData)//反序列化处理
        {
            if (hasSerializeData)//有序列化数据
                hp = deserialize.ReadInt32();
        }

        void IMissionArchiveItem.OnSerialize(BinaryWriter writer)//序列化处理
        {
            writer.Write(hp);
        }
    }
}
