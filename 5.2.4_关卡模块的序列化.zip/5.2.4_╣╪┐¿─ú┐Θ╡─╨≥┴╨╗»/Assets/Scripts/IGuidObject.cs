﻿namespace ACTBook
{
    public interface IGuidObject
    {
        long Guid { get; }
    }
}
