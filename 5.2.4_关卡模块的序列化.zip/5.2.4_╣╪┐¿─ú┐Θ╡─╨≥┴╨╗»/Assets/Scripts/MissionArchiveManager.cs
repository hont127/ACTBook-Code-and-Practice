﻿using System.IO;
using System.Collections.Generic;

namespace ACTBook
{
    public class MissionArchiveManager
    {
        static MissionArchiveManager mInstance;//这里使用非mono单例
        public static MissionArchiveManager Instance { get { return mInstance ?? (mInstance = new MissionArchiveManager()); } }
        List<IMissionArchiveItem> mMissionArchiveItemList;


        public MissionArchiveManager()
        {
            mMissionArchiveItemList = new List<IMissionArchiveItem>();
        }

        public void RegistMissionArchiveItem(IMissionArchiveItem archiveItem)
        {
            mMissionArchiveItemList.Add(archiveItem);//注册组件
        }

        public void UnregistMissionArchiveItem(IMissionArchiveItem archiveItem)
        {
            mMissionArchiveItemList.Remove(archiveItem);//反注册组件
        }

        public void MissionInitialization()//常规进入关卡调用此初始化
        {
            for (int i = 0, iMax = mMissionArchiveItemList.Count; i < iMax; i++)
            {
                var item = mMissionArchiveItemList[i];
                item.OnMissionArchiveInitialization(null, false);
            }
        }

        public void MissionInitialization(Stream stream)//读档或检查点调用此初始化
        {
            using (var binaryReader = new BinaryReader(stream))
            {
                var serializeCount = binaryReader.ReadInt32();//获取之前组件数量
                for (int i = 0; i < serializeCount; i++)
                {
                    var guid = binaryReader.ReadInt64();//读到ID
                    var bytes_length = binaryReader.ReadInt32();
                    var bytes = binaryReader.ReadBytes(bytes_length);//读到字节
                    for (int archiveIndex = 0, archiveIndex_Max = mMissionArchiveItemList.Count; i < archiveIndex_Max; i++)
                    {
                        var item = mMissionArchiveItemList[archiveIndex];
                        if (item.Guid != guid) continue;//不匹配则跳出
                        using (var archiveItemStream = new MemoryStream(bytes))
                        using (var archiveItemStreamReader = new BinaryReader(archiveItemStream))
                            item.OnMissionArchiveInitialization(archiveItemStreamReader, true);//反序列化操作
                    }
                }
            }
        }

        public void MissionSerialize(Stream stream)//关卡序列化
        {
            using (var binaryWriter = new BinaryWriter(stream))
            {
                binaryWriter.Write(mMissionArchiveItemList.Count);//当前组件数
                for (int i = 0, iMax = mMissionArchiveItemList.Count; i < iMax; i++)
                {
                    var item = mMissionArchiveItemList[i];
                    using (var archiveItemStream = new MemoryStream())//组件的内存流
                    {
                        using (var archiveItemStreamWriter = new BinaryWriter(archiveItemStream))
                        {
                            item.OnSerialize(archiveItemStreamWriter);//序列化事件
                            var bytes = archiveItemStream.ToArray();
                            binaryWriter.Write(item.Guid);//写入ID
                            binaryWriter.Write(bytes.Length);
                            binaryWriter.Write(bytes);//写入字节
                        }
                    }
                }
            }
        }
    }
}