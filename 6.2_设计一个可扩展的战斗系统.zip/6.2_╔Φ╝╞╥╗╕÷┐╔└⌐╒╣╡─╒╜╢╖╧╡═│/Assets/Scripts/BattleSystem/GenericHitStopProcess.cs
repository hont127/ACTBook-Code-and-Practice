﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class GenericHitStopProcess : MonoBehaviour
    {
        public HitStopBattleComponent hitStopBattleComponent;
        public Animator animator;
        float mHitRecoverTimer;
        int mIsHitAnimatorHash;
        public bool HitStop { get { return mHitRecoverTimer > 0; } }//是否处于僵直状态

        void Awake()
        {
            hitStopBattleComponent.OnHitStopTriggered += OnHitStopTriggered;
            mIsHitAnimatorHash = Animator.StringToHash("IsHit");
        }
        void Update()
        {
            if (mHitRecoverTimer > 0)//简易的僵直度反馈
                animator.SetBool(mIsHitAnimatorHash, true);
            else
                animator.SetBool(mIsHitAnimatorHash, false);

            mHitRecoverTimer = Mathf.Max(0f, mHitRecoverTimer - Time.deltaTime);//僵直恢复
        }
        void OnHitStopTriggered(float hitStopValue)
        {
            mHitRecoverTimer = Mathf.Max(mHitRecoverTimer, hitStopValue);//更新僵直时间
        }
    }
}
