﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public abstract class BattleObjectComponentBase : MonoBehaviour
    {
        protected BattleObject mBattleObject;

        public virtual void Initialization(BattleObject battleObject)//初始化
        {
            mBattleObject = battleObject;
        }
    }
}
