﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class HitStopBattleComponent : BattleObjectComponentBase
    {
        public float toEnemyHitStopTime;//赋予敌人的僵直时间
        public event Action<float> OnHitStopTriggered;//进入僵直状态事件，参数为僵直时间

        public override void Initialization(BattleObject battleObject)//初始化函数
        {
            base.Initialization(battleObject);
            battleObject.OnContactOtherFaction += OnContactOtherFactionCallback;
        }
        void OnContactOtherFactionCallback(BattleObject sender, BattleObject other)//接触不同阵营后的处理
        {
            var anotherHitStopComponent = other.GetBattleObjectComponent<HitStopBattleComponent>();
            if (anotherHitStopComponent != null)
            {
                if (toEnemyHitStopTime <= 0) return;//没有僵直信息则跳出
                if (anotherHitStopComponent.OnHitStopTriggered != null)//触发僵直事件，并传入僵直时间
                    anotherHitStopComponent.OnHitStopTriggered(toEnemyHitStopTime);
            }
        }
    }
}
