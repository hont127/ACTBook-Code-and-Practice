﻿using UnityEngine;

namespace ACTBook
{
    public class Tutorial : MonoBehaviour
    {
        void OnGUI()
        {
            GUILayout.Box("请查看Resources/AnimationEventConfigurator配置文件"
                + "\n修改[Component]/AnimationEventReceiver中AnimatorController上" +
                "\n链接的Animation文件事件，可修改其绑定的事件ID");
        }
    }
}
