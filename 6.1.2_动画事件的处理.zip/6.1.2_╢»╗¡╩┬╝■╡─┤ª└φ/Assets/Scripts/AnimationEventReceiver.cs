﻿using UnityEngine;

namespace ACTBook
{
    public class AnimationEventReceiver : MonoBehaviour
    {
        void AnimationEventTrigger(int id)//接收动画事件绑定函数
        {
            AnimationEventConfigurator.InstantiateAnimationEventItem(gameObject, id);
        }
    }
}