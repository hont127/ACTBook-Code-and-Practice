﻿using UnityEngine;

namespace ACTBook
{
    public class VectorSumAndSub : MonoBehaviour
    {
        public Transform vector1;
        public Transform vector2;


        void OnDrawGizmos()
        {
            Gizmos.DrawLine(vector1.position, vector1.forward);
            Gizmos.DrawLine(vector2.position, vector2.forward);

            var cacheColor = Gizmos.color;
            Gizmos.color = Color.yellow;

            var sum = (vector1.forward + vector2.forward).normalized;
            var sub = (vector1.forward - vector2.forward).normalized;
            Gizmos.DrawLine(Vector3.zero, sum);
            Gizmos.DrawLine(Vector3.zero, sub);
            //此处使用黄色向量标记加减后结果

            Gizmos.color = cacheColor;
        }
    }
}
