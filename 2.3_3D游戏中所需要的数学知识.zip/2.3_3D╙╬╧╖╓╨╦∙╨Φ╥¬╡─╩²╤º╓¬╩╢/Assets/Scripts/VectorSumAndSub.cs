﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class VectorSumAndSub : MonoBehaviour
    {
        public Transform vector1;
        public Transform vector2;
        public Transform vector_Result_Sum;
        public Transform vector_Result_Sub;


        void OnDrawGizmos()
        {
            Gizmos.DrawLine(vector1.position, vector1.forward);
            Gizmos.DrawLine(vector2.position, vector2.forward);

            var cacheColor = Gizmos.color;
            Gizmos.color = Color.yellow;

            var sum = (vector1.forward + vector2.forward).normalized;
            var sub = (vector1.forward - vector2.forward).normalized;
            Gizmos.DrawLine(Vector3.zero, sum);
            Gizmos.DrawLine(Vector3.zero, sub);

            Gizmos.color = cacheColor;
        }
    }
}
