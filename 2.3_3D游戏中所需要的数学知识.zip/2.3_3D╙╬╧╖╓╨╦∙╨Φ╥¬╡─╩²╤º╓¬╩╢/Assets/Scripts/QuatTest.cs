﻿using UnityEngine;

namespace ACTBook
{
    public class QuatTest : MonoBehaviour
    {
        void Update()
        {
            var quat1 = Quaternion.AngleAxis(-90, Vector3.forward);
            var quat2 = Quaternion.AngleAxis(Time.time * 180, Vector3.right);
            //transform.rotation = quat1 * quat2; /*需要区别顺序*/
            transform.rotation = quat1 * quat2;
        }
    }
}
