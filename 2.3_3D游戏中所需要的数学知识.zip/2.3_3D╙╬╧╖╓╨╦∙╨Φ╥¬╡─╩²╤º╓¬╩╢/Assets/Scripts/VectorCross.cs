﻿using UnityEngine;

namespace ACTBook
{
    public class VectorCross : MonoBehaviour
    {
        public Transform vector1;
        public Transform vector2;


        void OnDrawGizmos()
        {
            Gizmos.DrawLine(vector1.position, vector1.position + vector1.forward);
            Gizmos.DrawLine(vector2.position, vector2.position + vector2.forward);
            var cross = Vector3.Cross(vector1.forward, vector2.forward).normalized;
            Gizmos.DrawLine(vector1.position, vector1.position + cross);
            //此处使用Gizmos绘制了一根线来表示叉乘结果。
        }
    }
}
