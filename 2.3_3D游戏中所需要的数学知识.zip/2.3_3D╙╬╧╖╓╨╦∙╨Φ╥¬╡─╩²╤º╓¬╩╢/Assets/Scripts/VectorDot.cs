﻿using UnityEngine;

namespace ACTBook
{
    public class VectorDot : MonoBehaviour
    {
        public Transform vector1;
        public Transform vector2;


        void OnDrawGizmos()
        {
            var cacheColor = Gizmos.color;
            Gizmos.color = Color.Lerp(Color.white, Color.red, Vector3.Dot(vector1.forward, vector2.forward) * 0.5f + 0.5f);
            Gizmos.DrawLine(vector1.position, vector1.position + vector1.forward);
            Gizmos.DrawLine(vector2.position, vector2.position + vector2.forward);
            //此处使用两根线的颜色来表示点乘
            Gizmos.color = cacheColor;
        }
    }
}
