﻿using UnityEngine;

namespace ACTBook
{
    public class VectorProj : MonoBehaviour
    {
        public Transform vector1;
        public Transform vector2;


        void OnDrawGizmos()
        {
            var relativeLength = vector2.position + Vector3.Project(vector1.position - vector2.position, vector2.forward);

            Gizmos.DrawWireSphere(vector1.position, 0.1f);
            Gizmos.DrawWireSphere(relativeLength, 0.1f);
            Gizmos.DrawLine(vector2.position, vector2.position + vector2.forward);
            //此处演示vector1(Transform)在vector2 forward方向上的投影点
        }
    }
}
