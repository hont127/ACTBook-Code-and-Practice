﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public struct ComposeAttackContext
    {
        public Transform CasterTransform { get; set; }
        public Animator Animator { get; set; }
    }
}
