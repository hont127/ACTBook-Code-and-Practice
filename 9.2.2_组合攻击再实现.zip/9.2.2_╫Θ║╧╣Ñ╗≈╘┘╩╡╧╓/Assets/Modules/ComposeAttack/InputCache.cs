﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class InputCache : MonoBehaviour
    {
        public static bool AttackButton { get; set; }


        void Update()
        {
            AttackButton = Input.GetKeyDown(KeyCode.J);
        }
    }
}
