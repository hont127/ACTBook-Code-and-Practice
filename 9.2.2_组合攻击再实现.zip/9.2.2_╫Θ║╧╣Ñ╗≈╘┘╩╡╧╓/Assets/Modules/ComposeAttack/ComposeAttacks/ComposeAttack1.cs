﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    [CreateAssetMenu(fileName = "ComposeAttack1", menuName = "ComposeAttacks/Attack1")]
    public class ComposeAttack1 : ComposeAttackBase
    {
        public float yOffset = 1f;//检测碰撞的y轴偏移
        public Vector3 size = new Vector3(1f, 2f, 1f);//检测碰撞的大小
        public Vector4 aroundOffset = new Vector4(0.5f, 0.5f, 0.5f, 0.5f);//前后左右检测距离偏移
        public LayerMask layerMask;
        bool mIsForwardAndBackword;

        public override bool CanTrigger(ComposeAttackContext context, bool prepareTrigger)
        {
            var upAxis = -Physics.gravity.normalized;//垂直轴
            var right = Vector3.ProjectOnPlane(context.CasterTransform.right, upAxis);//投影的右侧方向
            var forward = Vector3.ProjectOnPlane(context.CasterTransform.forward, upAxis);//投影的前方
            var upAxisOffset = upAxis * yOffset;//垂直轴偏移
            var forwardFlag = Physics.CheckBox(context.CasterTransform.position
                     + upAxisOffset + forward * aroundOffset.x
                  , size
                  , Quaternion.identity
                  , layerMask);
            var backwardFlag = Physics.CheckBox(context.CasterTransform.position
                    + upAxisOffset + (-forward) * aroundOffset.y
                , size
                , Quaternion.identity
                , layerMask);

            if (forwardFlag && backwardFlag)//前后都有敌人
            {
                if (prepareTrigger) mIsForwardAndBackword = true;
                return true;
            }
            var leftFlag = Physics.CheckBox(context.CasterTransform.position
                    + upAxisOffset + (-right) * aroundOffset.z
                , size
                , Quaternion.identity
                , layerMask);
            var rightFlag = Physics.CheckBox(context.CasterTransform.position
                    + upAxisOffset + right * aroundOffset.w
                , size
                , Quaternion.identity
                , layerMask);

            if (rightFlag && leftFlag)//左右都有敌人
            {
                if (prepareTrigger) mIsForwardAndBackword = false;
                return true;
            }
            return false;
        }

        public override IEnumerator Trigger(ComposeAttackContext context)
        {
            Debug.Log("Trigger!");

            yield return null;
            if (mIsForwardAndBackword)//前后都有敌人的情况
            {
                context.Animator.Play("Range_Attack", 0, 0);
            }
            else//左右都有敌人的情况
            {
                context.CasterTransform.forward = context.CasterTransform.right;
                //先将角色朝向切至右边
                context.Animator.Play("Range_Attack", 0, 0);
            }
        }
    }
}
