﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public abstract class ComposeAttackBase : ScriptableObject
    {
        public abstract bool CanTrigger(ComposeAttackContext context, bool prepareTrigger);
        public abstract IEnumerator Trigger(ComposeAttackContext context);
    }
}
