﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class ComposeAttackController_Test : MonoBehaviour
    {
        public ComposeAttackController mComposeAttackController;
        public Animator[] animators;


        void Update()
        {
            if (InputCache.AttackButton)
            {
                StartCoroutine(mComposeAttackController.TriggeredComposeSkill(mComposeAttackController.TriggerableComposeAttackIndex));
                for (int i = 0; i < animators.Length; i++)
                {
                    animators[i].enabled = false;
                    animators[i].enabled = true;
                    animators[i].Play("LightHit", 0, 0);
                }
            }
        }
    }
}
