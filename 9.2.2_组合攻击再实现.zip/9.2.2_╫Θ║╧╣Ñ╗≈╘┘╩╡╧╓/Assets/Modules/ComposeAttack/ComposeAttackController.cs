﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class ComposeAttackController : MonoBehaviour
    {
        [SerializeField] Animator animator = null;//上下文所需接口，面板暴露参数
        [SerializeField] ComposeAttackBase[] composeAttackArray = null;//组件列表面板暴露参数
        public int TriggerableComposeAttackIndex { get; private set; }//当前已触发的组合技能索引
        public ComposeAttackBase[] GetComposeAttackArray()//对外提供组合技能数组列表
        {
            return composeAttackArray;
        }
        public void Update()//每一帧更新组合技能是否触发逻辑，但可修改.enabled关闭脚本更新
        {
            var context = new ComposeAttackContext() { Animator = animator, CasterTransform = transform };
            for (int i = 0; i < composeAttackArray.Length; i++)
            {
                var item = composeAttackArray[i];
                if (item.CanTrigger(context, true))//触发条件检测
                {
                    TriggerableComposeAttackIndex = i;
                    break;
                }
            }
        }
        public IEnumerator TriggeredComposeSkill(int index)//组合技能的触发接口
        {
            if (index > composeAttackArray.Length - 1)
                throw new ArgumentOutOfRangeException();
            var context = new ComposeAttackContext() { Animator = animator, CasterTransform = transform };
            yield return composeAttackArray[index].Trigger(context);
        }
    }
}
