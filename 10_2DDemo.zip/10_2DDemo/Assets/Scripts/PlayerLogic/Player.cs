﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public partial class Player : MonoBehaviour
    {
        public enum EState { Standby, Move, Jump, Skill, Hit, Freeze }//状态枚举
        public Animator animator;
        public Rigidbody selfRigidbody;//刚体对象
        public BattleObject battleObject;//战斗对象
        public CharacterMotor motor;//Motor组件引用

        Coroutine mCurrentActionCoroutine;//当前动作协程
        public EState State { get; private set; }//当前状态

        void Awake()
        {
            PlayerAttack_Init();
            PlayerMove_Init();
            PlayerJump_Init();
            PlayerHit_Init();

            StartCoroutine(StateLoop());

            EnemyTargets.Instance.RegistTarget(gameObject, 1f);
        }

        void OnDestroy()
        {
            EnemyTargets.Instance.UnregistTarget(gameObject);
        }

        IEnumerator StateLoop()
        {
            while (true)
            {
                IEnumerator currentAction = null;

                if (PlayerAttack_CanExecute())
                    currentAction = PlayerAttack_Execute();

                else if (PlayerJump_CanExecute())
                    currentAction = PlayerJump_Execute();

                else if (PlayerMove_CanExecute())
                    currentAction = PlayerMove_Execute();

                if (currentAction != null)
                    mCurrentActionCoroutine = StartCoroutine(ExecuteCurrentAction(currentAction));

                yield return null;
            }
        }

        IEnumerator ExecuteCurrentAction(IEnumerator actionBody)
        {
            yield return actionBody;
            mCurrentActionCoroutine = null;
        }

        void ImmediateStopCurrentAction()
        {
            if (mCurrentActionCoroutine != null)
                StopCoroutine(mCurrentActionCoroutine);
            mCurrentActionCoroutine = null;
        }
    }
}
