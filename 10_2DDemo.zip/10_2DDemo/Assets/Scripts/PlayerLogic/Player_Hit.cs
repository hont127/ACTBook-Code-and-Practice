﻿using System.Collections;
using UnityEngine;

namespace ACTBook
{
    public partial class Player : MonoBehaviour
    {
        Coroutine mHitCoroutine;
        int mHitAnimatorHash;


        void PlayerHit_Init()
        {
            mHitAnimatorHash = Animator.StringToHash("Hit");

            var damageBattleComponent = battleObject.GetBattleObjectComponent<DamageBattleComponent>();
            damageBattleComponent.OnHurt += OnHurt;
            damageBattleComponent.OnDied += OnDied;
        }

        void OnHurt(BattleObject sender, BattleObject other, int damage)
        {
            if (damage < 1) return;
            if (State == EState.Jump) return;

            if (State == EState.Move)
            {
                animator.SetBool(mLocomotionAnimatorHash, false);
            }

            if (State == EState.Skill)
            {
                animator.ResetTrigger(mAttackAnimatorHash);
            }

            if (mCurrentActionCoroutine != null)
            {
                StopCoroutine(mCurrentActionCoroutine);
                mCurrentActionCoroutine = null;
            }

            if (mHitCoroutine != null)
            {
                StopCoroutine(mHitCoroutine);
                mHitCoroutine = null;
            }

            mHitCoroutine = StartCoroutine(HitAction());
        }

        void OnDied(BattleObject sender)
        {
            //TODO.
            Destroy(gameObject);
        }

        IEnumerator HitAction()
        {
            State = EState.Hit;
            animator.SetTrigger(mHitAnimatorHash);
            animator.Update(0);

            while (true)
            {
                if (animator.GetCurrentAnimatorStateInfo(0).IsTag("Standby"))
                {
                    animator.ResetTrigger(mHitAnimatorHash);
                    break;
                }

                yield return null;
            }

            State = EState.Standby;
        }
    }
}
