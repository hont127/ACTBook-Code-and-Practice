﻿using System;
using System.Collections;
using UnityEngine;

namespace ACTBook
{
    public partial class Player : MonoBehaviour
    {
        const int OVERLAPSPHERE_CACHE_COUNT = 10;//缓存数组常量长度
        [Serializable]
        public struct AttackSettings
        {
            public LayerMask characterLayerMask;//LayerMask过滤信息
            public string enemyTag;//敌人标签
        }
        public AttackSettings attackSettings;
        Collider[] mCacheColliderArray;//用于投射的缓存数组
        int mAttackAnimatorHash;//攻击Animator变量哈希


        void PlayerAttack_Init()//部分类的手动初始化函数
        {
            mAttackAnimatorHash = Animator.StringToHash("Attack");//初始化Animator哈希
            mCacheColliderArray = new Collider[OVERLAPSPHERE_CACHE_COUNT];//初始化缓存数组
        }

        bool PlayerAttack_CanExecute()//状态调度判断逻辑
        {
            var inputFlag = InputCache.Instance.Fire.WasPressed;
            var stateFlag = State == EState.Move || State == EState.Standby;

            return inputFlag && stateFlag;
        }

        IEnumerator PlayerAttack_Execute()//状态执行逻辑
        {
            ImmediateStopCurrentAction();
            if (State == EState.Move)
                animator.SetBool(mLocomotionAnimatorHash, false);
            State = EState.Skill;

            while (true)
            {
                if (InputCache.Instance.Fire.WasPressed)
                {
                    const float ENEMY_FIX_RADIUS = 1f;
                    const float DOT_LIMIT = 0.7f;
                    var closestEnemy = GetClosestEnemy(ENEMY_FIX_RADIUS, DOT_LIMIT);
                    if (closestEnemy != null)
                    {
                        var dir = closestEnemy.position - transform.position;
                        dir = Vector3.ProjectOnPlane(dir, -Physics.gravity.normalized);
                        transform.forward = dir;
                    }
                    animator.SetTrigger(mAttackAnimatorHash);
                    animator.Update(0);
                }

                if (!animator.IsInTransition(0) && animator.GetCurrentAnimatorStateInfo(0).IsTag("Standby"))
                {
                    animator.ResetTrigger(mAttackAnimatorHash);
                    break;
                }

                yield return null;
            }
            State = EState.Standby;
        }

        Transform GetClosestEnemy(float radius, float dotLimit)
        {
            var count = Physics.OverlapSphereNonAlloc(transform.position, radius, mCacheColliderArray, attackSettings.characterLayerMask);//返回半径范围内碰撞器
            var maxDotValue = 1f;
            var maxDotTransform = default(Transform);
            for (int i = 0; i < count; i++)//变量所有覆盖的碰撞器
            {
                var characterCollider = mCacheColliderArray[i];
                if (characterCollider.transform == transform) continue;//如果是自己跳过
                if (characterCollider.CompareTag(attackSettings.enemyTag))//确保标签一致
                {
                    var dot = Vector3.Dot((characterCollider.transform.position - transform.position).normalized, transform.forward);
                    if (dot > dotLimit && dot > maxDotValue)//取最大点乘结果的敌人
                    {
                        maxDotValue = dot;
                        maxDotTransform = characterCollider.transform;
                    }
                }
            }
            return maxDotTransform;//返回最接近的那个敌人
        }
    }
}
