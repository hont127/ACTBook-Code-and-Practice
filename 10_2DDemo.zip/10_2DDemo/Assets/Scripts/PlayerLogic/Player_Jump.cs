﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public partial class Player : MonoBehaviour
    {
        [Serializable]
        public struct JumpSettings
        {
            public Transform[] groundPoints;
            public LayerMask groundLayerMask;//地面LayerMask
            public Vector4 arg;
            public AnimationCurve riseCurve;
            public AnimationCurve directionJumpCurve;
        }

        [SerializeField]
        JumpSettings jumpSettings = new JumpSettings()
        {
            groundLayerMask = ~0,
            riseCurve = new AnimationCurve(new Keyframe[] { new Keyframe(0f, 0f), new Keyframe(0.5f, 1f), new Keyframe(1f, 0f) }),
            directionJumpCurve = new AnimationCurve(new Keyframe[] { new Keyframe(0f, 0f), new Keyframe(0.5f, 1f), new Keyframe(1f, 0f) }),
        };

        int mJumpAnimatorHash;//移动Animator变量哈希
        float mGroundedDelay;//延迟检测变量
        Coroutine mJumpCoroutine;//跳跃协程序


        void PlayerJump_Init()
        {
            mJumpAnimatorHash = Animator.StringToHash("Jump");
        }

        bool PlayerJump_CanExecute()
        {
            var inputFlag = InputCache.Instance.Jump.WasPressed;
            var stateFlag = State == EState.Move || State == EState.Standby;

            return inputFlag && stateFlag && motor.IsOnGround;
        }

        IEnumerator PlayerJump_Execute()
        {
            ImmediateStopCurrentAction();
            if (State == EState.Move)
                animator.SetBool(mLocomotionAnimatorHash, false);
            State = EState.Jump;

            var upAxis = -Physics.gravity.normalized;//up轴向
            mGroundedDelay = Time.maximumDeltaTime * 2f;//两帧延迟
            selfRigidbody.useGravity = false;//暂时关闭重力
            var t = jumpSettings.arg.w;//时间插值

            animator.SetBool(mJumpAnimatorHash, true);

            do
            {
                var t_riseCurve = jumpSettings.riseCurve.Evaluate(t);//上升力曲线采样
                var t_directionJump = jumpSettings.directionJumpCurve.Evaluate(t);//方向力曲线采样
                var gravity = Vector3.Lerp(-upAxis, upAxis, t_riseCurve) * jumpSettings.arg.y;
                var forward = Vector3.Lerp(motor.transform.right * jumpSettings.arg.z * Time.fixedDeltaTime, Vector3.zero, t_directionJump);
                //获得方向并乘以系数
                selfRigidbody.velocity = gravity + forward;//更新速率
                t = Mathf.Clamp01(t + Time.deltaTime * jumpSettings.arg.x);//更新插值
                yield return null;
            } while (t < 1f || !motor.IsOnGround);

            animator.SetBool(mJumpAnimatorHash, false);
            selfRigidbody.useGravity = true;//恢复重力

            State = EState.Standby;
        }
    }
}
