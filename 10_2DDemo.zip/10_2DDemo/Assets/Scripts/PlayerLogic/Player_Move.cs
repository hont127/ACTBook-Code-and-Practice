﻿using System.Collections;
using UnityEngine;

namespace ACTBook
{
    public partial class Player : MonoBehaviour
    {
        const float INPUT_EPS = 0.01f;
        public float speed = 65f;//移动速度

        int mLocomotionAnimatorHash;//移动Animator变量哈希


        void PlayerMove_Init()
        {
            mLocomotionAnimatorHash = Animator.StringToHash("Locomotion");
        }

        bool PlayerMove_CanExecute()
        {
            var moveDirection = Vector3.right * InputCache.Instance.Move.X;
            return State == EState.Standby && moveDirection.magnitude > INPUT_EPS;
        }

        IEnumerator PlayerMove_Execute()
        {
            const float INPUT_EPS = 0.01f;
            var moveDirection = Vector3.zero;

            ImmediateStopCurrentAction();
            State = EState.Move;

            do
            {
                moveDirection = (Vector3.right * InputCache.Instance.Move.X).normalized;

                if (moveDirection.magnitude > INPUT_EPS)//是否有输入方向
                {
                    var finalDirection = moveDirection;
                    selfRigidbody.velocity = finalDirection * speed * Time.fixedDeltaTime;
                    selfRigidbody.transform.right = finalDirection;

                    animator.SetBool(mLocomotionAnimatorHash, true);//更新Animator变量
                }
                else//没有移动
                {
                    animator.SetBool(mLocomotionAnimatorHash, false);//更新Animator变量
                    selfRigidbody.velocity = Vector3.zero;
                    break;
                }

                yield return null;

            } while (true);

            State = EState.Standby;
        }
    }
}
