﻿using UnityEngine;

namespace ACTBook
{
    public class AnimationEventReceiver : MonoBehaviour
    {
        public bool modifyFaction;


        void AnimationEventTrigger(int id)
        {
            var go = AnimationEventConfigurator.InstantiateAnimationEventItem(gameObject, id);
            if (go != null && modifyFaction)
            {
                var battleObjects = go.GetComponentsInChildren<BattleObject>(true);
                var selfFaction = GetComponent<BattleObject>().faction;
                for (int i = 0; i < battleObjects.Length; i++)
                    battleObjects[i].faction = selfFaction;
            }
        }
    }
}
