﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    [CreateAssetMenu(fileName = "AnimationEventConfigurator", menuName = "Demo2D/AnimationEventConfigurator")]
    public class AnimationEventConfigurator : ScriptableObject
    {
        [Serializable]
        public class CategoryInfo//使用分类便于配置
        {
            public string category;
            public List<AnimationEventItem> animationEventInfoList = new List<AnimationEventItem>();
        }
        [Serializable]
        public class AnimationEventItem//动画事件实例信息
        {
            public int id;
            public string resourcePath;//资源路径
            public Vector3 positionOffset;
            public Vector3 rotateOffset;
        }
        public CategoryInfo[] categoryInfoArray;


        public static GameObject InstantiateAnimationEventItem(GameObject sender, int id)
        {
            const string CONF_RES_PATH = "AnimationEventConfigurator";//配置路径
            var conf = Resources.Load<AnimationEventConfigurator>(CONF_RES_PATH);//获取配置
            for (int i = 0; i < conf.categoryInfoArray.Length; i++)
            {
                var categoryItem = conf.categoryInfoArray[i];
                for (int j = 0, jMax = categoryItem.animationEventInfoList.Count; j < jMax; j++)//获事件
                {
                    var eventItem = categoryItem.animationEventInfoList[j];
                    if (eventItem.id == id)//比较ID
                    {
                        var instantiateGO = Instantiate(Resources.Load<GameObject>(eventItem.resourcePath), sender.transform.position, sender.transform.rotation);
                        var sender_rotation = sender.transform.rotation;
                        instantiateGO.transform.position += sender_rotation * eventItem.positionOffset;//设置偏移
                        instantiateGO.transform.eulerAngles += sender_rotation * eventItem.rotateOffset;
                        return instantiateGO;
                    }
                }
            }
            return null;
        }
    }
}
