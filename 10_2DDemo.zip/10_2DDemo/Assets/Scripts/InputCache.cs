﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using InControl;
using BindingsExample;

namespace ACTBook
{
    public class InputCache : PlayerActionSet
    {
        static InputCache mInstance;
        public static InputCache Instance { get { return mInstance ?? (mInstance = new InputCache()); } }

        public PlayerAction Fire { get; private set; }
        public PlayerAction Jump { get; private set; }
        public PlayerTwoAxisAction Move { get; private set; }


        public InputCache()
        {
            Fire = CreatePlayerAction("Fire");
            Fire.AddDefaultBinding(Key.J);
            Fire.AddDefaultBinding(InputControlType.Action3);

            Jump = CreatePlayerAction("Jump");
            Jump.AddDefaultBinding(Key.K);
            Jump.AddDefaultBinding(InputControlType.Action1);

            var left = CreatePlayerAction("Move Left");
            var right = CreatePlayerAction("Move Right");
            var up = CreatePlayerAction("Move Up");
            var down = CreatePlayerAction("Move Down");
            right.AddDefaultBinding(Key.RightArrow);
            left.AddDefaultBinding(Key.LeftArrow);
            up.AddDefaultBinding(Key.UpArrow);
            down.AddDefaultBinding(Key.DownArrow);
            left.AddDefaultBinding(InputControlType.LeftStickLeft);
            right.AddDefaultBinding(InputControlType.LeftStickRight);
            up.AddDefaultBinding(InputControlType.LeftStickUp);
            down.AddDefaultBinding(InputControlType.LeftStickDown);

            Move = CreateTwoAxisPlayerAction(left, right, down, up);
        }
    }
}
