﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class CharacterSpawner : MonoBehaviour
    {
        [SerializeField]
        float firstDelay = 3f;
        [SerializeField]
        GameObject template;
        [SerializeField]
        Transform[] spawnPoints;

        List<GameObject> mCacheInstancedGOList;


        IEnumerator Start()
        {
            mCacheInstancedGOList = new List<GameObject>(10);

            yield return new WaitForSeconds(firstDelay);

            while (true)
            {
                mCacheInstancedGOList.Clear();
                for (int i = 0; i < spawnPoints.Length; i++)
                {
                    var spawnPoint = spawnPoints[i];

                    var instancedGO = Instantiate(template, spawnPoint.position, spawnPoint.rotation);
                    instancedGO.name = template + i.ToString();
                    mCacheInstancedGOList.Add(instancedGO);
                }

                yield return new WaitUntil(() =>
                {
                    var flag = true;
                    for (int i = 0, iMax = mCacheInstancedGOList.Count; i < iMax; i++)
                    {
                        flag &= mCacheInstancedGOList[i] == null;
                    }
                    return flag;
                });

                yield return new WaitForSeconds(3f);
            }
        }
    }
}
