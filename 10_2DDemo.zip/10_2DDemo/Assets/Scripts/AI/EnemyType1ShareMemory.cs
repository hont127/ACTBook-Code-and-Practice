﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class EnemyType1ShareMemory
    {
        static EnemyType1ShareMemory mInstance;//单例
        public static EnemyType1ShareMemory Instance { get { return mInstance ?? (mInstance = new EnemyType1ShareMemory()); } }
        int mAttackerCount;
        public int AttackCount { get { return mAttackerCount; } }//当前攻击者计数
        public void NoticeAttack()//通知攻击
        {
            mAttackerCount++;
        }
        public void EndOfAttack()//结束攻击
        {
            mAttackerCount--;
        }
    }
}
