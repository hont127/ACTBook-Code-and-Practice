﻿using System.Collections;
using UnityEngine;

namespace ACTBook
{
    public class EnemyType1AI : MonoBehaviour
    {
        const string STANDBY_ANIM_TAG = "StandBy";

        enum EState { StandBy, Active, Wander, Attack, Hit, Died }

        public Animator animator;
        public float activeRange = 8f;//激活范围
        public float attackRange = 2f;//攻击范围
        public float speed = 20f;//移动速度
        public float wanderRange = 3f;
        public CapsuleCollider capsuleCollider;
        public LayerMask wallLayerMask;
        public BattleObject battleObject;
        public CharacterMotor characterMotor;
        int mAttackAnimHash;
        int mLocomotionAnimHash;
        int mHitAnimHash;
        bool mIsNoticeAttack;
        Coroutine mBehaviourCoroutine;//主协程
        GameObject mCurrentTarget;//当前目标


        void Start()
        {
            mAttackAnimHash = Animator.StringToHash("Attack");
            mLocomotionAnimHash = Animator.StringToHash("Locomotion");
            mHitAnimHash = Animator.StringToHash("Hit");

            var damageBattleComponent = battleObject.GetBattleObjectComponent<DamageBattleComponent>();
            damageBattleComponent.OnHurt += OnHurt;
            damageBattleComponent.OnDied += OnDied;

            mBehaviourCoroutine = StartCoroutine(StandByBehaviour());
        }

        void OnHurt(BattleObject sender, BattleObject other, int damage)
        {
            if (damage <= 0) return;

            if (mBehaviourCoroutine != null)
            {
                animator.SetBool(mLocomotionAnimHash, false);

                if (mIsNoticeAttack)
                {
                    EnemyType1ShareMemory.Instance.EndOfAttack();
                    mIsNoticeAttack = false;
                }

                StopCoroutine(mBehaviourCoroutine);
                mBehaviourCoroutine = null;
            }
            mBehaviourCoroutine = StartCoroutine(HurtBehaviour());
        }

        void OnDied(BattleObject sender)
        {
            StopAllCoroutines();
            Destroy(gameObject);
        }

        void UpdateTarget()//更新当前目标
        {
            var maxHatred = -1f;
            for (int i = 0, iMax = EnemyTargets.Instance.TargetList.Count; i < iMax; i++)
            {
                var currentTarget = EnemyTargets.Instance.TargetList[i];
                if (currentTarget.Hatred > maxHatred)//筛选最大仇恨值的目标
                {
                    if (IsInActiveRange(currentTarget.GameObject.transform))//是否在激活范围
                    {
                        mCurrentTarget = currentTarget.GameObject;
                        maxHatred = currentTarget.Hatred;//更新目标
                    }
                }
            }
        }

        bool IsInActiveRange(Transform target)//是否在激活范围内
        {
            return Vector3.Distance(transform.position, target.position) <= activeRange;
        }

        bool IsInAttackRange(Transform target)//是否在攻击范围内
        {
            return Vector3.Distance(transform.position, target.position) <= attackRange;
        }

        IEnumerator StandByBehaviour()
        {
            while (true)
            {
                for (int i = 0, iMax = EnemyTargets.Instance.TargetList.Count; i < iMax; i++)
                {
                    var target = EnemyTargets.Instance.TargetList[i];
                    if (IsInActiveRange(target.GameObject.transform)
                        && characterMotor.IsOnGround)//有目标进入激活范围
                    {
                        yield return ActiveBehaviour();//进入激活行为
                    }
                }
                yield return null;
            }
        }

        IEnumerator ActiveBehaviour()
        {
            UpdateTarget();//更新目标，仇恨值筛选
            while (mCurrentTarget != null && IsInActiveRange(mCurrentTarget.transform))//确保目标没有离开
            {
                if (EnemyType1ShareMemory.Instance.AttackCount < 1)
                {
                    mIsNoticeAttack = true;
                    EnemyType1ShareMemory.Instance.NoticeAttack();
                    yield return AttackBehaviour(mCurrentTarget.transform);//攻击
                    mIsNoticeAttack = false;
                    EnemyType1ShareMemory.Instance.EndOfAttack();
                }

                yield return WanderBehaviour();

                yield return null;
            }
        }

        IEnumerator WanderBehaviour()
        {
            var wanderRangeHalf = wanderRange * 0.5f;
            var center = capsuleCollider.transform.localToWorldMatrix.MultiplyPoint3x4(capsuleCollider.center);
            var p0 = center + (-Vector3.right) * wanderRangeHalf;
            var p1 = center + Vector3.right * wanderRangeHalf;

            var upAxis = -Physics.gravity.normalized;
            var axis = capsuleCollider.direction == 0 ? Vector3.right : capsuleCollider.direction == 1 ? Vector3.up : Vector3.forward;
            var halfHeight = capsuleCollider.height * 0.5f;
            var min = capsuleCollider.transform.localToWorldMatrix.MultiplyPoint3x4(capsuleCollider.center + axis * -halfHeight);
            var max = capsuleCollider.transform.localToWorldMatrix.MultiplyPoint3x4(capsuleCollider.center + axis * halfHeight);
            var raycastHit = default(RaycastHit);
            var leftIsHit = Physics.CapsuleCast(min, max, capsuleCollider.radius, -Vector3.right, out raycastHit, wanderRangeHalf, wallLayerMask);
            if (leftIsHit) p0 = transform.position;
            var rightIsHit = Physics.CapsuleCast(min, max, capsuleCollider.radius, Vector3.right, out raycastHit, wanderRangeHalf, wallLayerMask);
            if (rightIsHit) p1 = transform.position;
            var selfHit = Physics.CheckCapsule(min, max, capsuleCollider.radius, wallLayerMask);
            if (selfHit) p0 = p1 = transform.position;

            const float EPS = 0.4f;
            const float DOT_EPS = -0.9f;
            var targetPosition = Vector3.Lerp(p0, p1, Random.Range(0f, 1f));
            var originDir = Vector3.ProjectOnPlane(targetPosition - transform.position, Physics.gravity.normalized).normalized;
            var toDir = Vector3.zero;
            do
            {
                toDir = targetPosition - transform.position;

                toDir = Vector3.ProjectOnPlane(toDir, Physics.gravity.normalized).normalized;
                transform.position += toDir * speed * Time.deltaTime;
                transform.right = toDir;
                animator.SetBool(mLocomotionAnimHash, true);//更新动画

                if (Vector3.Distance(transform.position, targetPosition) <= EPS || Vector3.Dot(toDir, originDir) <= DOT_EPS)
                    break;

                yield return null;

            } while (true);

            animator.SetBool(mLocomotionAnimHash, false);
        }

        IEnumerator HurtBehaviour()
        {
            animator.SetTrigger(mHitAnimHash);
            animator.Update(0);
            yield return new WaitUntil(() => !animator.IsInTransition(0) && animator.GetCurrentAnimatorStateInfo(0).IsTag(STANDBY_ANIM_TAG));
            animator.ResetTrigger(mHitAnimHash);
            yield return StandByBehaviour();
        }

        IEnumerator AttackBehaviour(Transform target)
        {
            var flag = true;
            while (target != null && !IsInAttackRange(target))
            {
                if (!IsInActiveRange(target))
                {
                    flag = false;
                    break;
                }
                var to = (target.position - transform.position);
                to = Vector3.ProjectOnPlane(to, Physics.gravity.normalized).normalized;
                transform.position += to * speed * Time.deltaTime;
                transform.right = to;
                animator.SetBool(mLocomotionAnimHash, true);//更新动画
                yield return null;
            }
            animator.SetBool(mLocomotionAnimHash, false);
            if (flag)
            {
                var to = (target.position - transform.position);
                to = Vector3.ProjectOnPlane(to, Physics.gravity.normalized).normalized;
                transform.right = to;
                animator.SetTrigger(mAttackAnimHash);//执行攻击
                animator.Update(0);
                yield return new WaitWhile(() => animator.IsInTransition(0) || !animator.GetCurrentAnimatorStateInfo(0).IsTag(STANDBY_ANIM_TAG));
            }
        }
    }
}
