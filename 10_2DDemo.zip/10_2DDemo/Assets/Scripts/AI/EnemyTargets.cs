﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public struct EnemyTargetInfo//目标信息结构
    {
        public GameObject GameObject { get; set; }//目标
        public float Hatred { get; set; }//仇恨值
    }
    public class EnemyTargets
    {
        static EnemyTargets mInstance;
        public static EnemyTargets Instance { get { return mInstance ?? (mInstance = new EnemyTargets()); } }
        readonly List<EnemyTargetInfo> mTargetList = new List<EnemyTargetInfo>();
        public IReadOnlyList<EnemyTargetInfo> TargetList { get { return mTargetList; } }//目标列表
        public void RegistTarget(GameObject target, float hatred)//注册目标
        {
            mTargetList.Add(new EnemyTargetInfo() { GameObject = target, Hatred = hatred });
        }
        public void UnregistTarget(GameObject target)//反注册目标
        {
            mTargetList.RemoveAll(m => m.GameObject == target);
        }
    }
}
