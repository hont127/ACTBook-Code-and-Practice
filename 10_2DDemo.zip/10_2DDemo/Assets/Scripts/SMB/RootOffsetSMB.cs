﻿using UnityEngine;

namespace ACTBook
{
    public class RootOffsetSMB : StateMachineBehaviour
    {
        public Vector3 offsetVelocity;
        Rigidbody mRigidbody;


        public override void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
        {
            base.OnStateMove(animator, stateInfo, layerIndex);

            mRigidbody = mRigidbody ?? animator.GetComponent<Rigidbody>();
            mRigidbody.velocity = animator.transform.rotation * offsetVelocity * Time.fixedDeltaTime;
        }
    }
}
