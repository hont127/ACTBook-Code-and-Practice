﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public class DestroyThis : MonoBehaviour
    {
        public float time = 0.3f;


        void OnEnable()
        {
            Destroy(gameObject, time);
        }
    }
}
