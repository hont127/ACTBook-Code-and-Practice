﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ACTBook
{
    public static class EasyFactionConst
    {
        public const int PLAYER = 1;//玩家
        public const int ENEMY = 2;//敌人
    }
}
