﻿namespace ACTBook
{
    public static class EasyFactionConst
    {
        public const int PLAYER = 1;//玩家
        public const int ENEMY = 2;//敌人
    }
}
