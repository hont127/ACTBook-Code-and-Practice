﻿using System;

namespace ACTBook
{
    public class DamageBattleComponent : BattleObjectComponentBase
    {
        public int hp;//生命值
        public bool isAttackState;//是否为攻击状态
        public int toEnemyDamage;//给予敌人伤害
        public bool godMode;//上帝模式

        bool mIsDied;//标记是否死亡

        public event Action<BattleObject, int, int> OnHPChanged;//HP改变事件
        public event Action<BattleObject> OnDied;//死亡事件
        public event Action<BattleObject, BattleObject, int> OnHurt;//受伤事件
        public event Action<BattleObject, BattleObject> OnAttackCompleted;//攻击成功事件
        public event Action<BattleObject, BattleObject> OnKilled;//击杀事件


        public override void Initialization(BattleObject battleObject)//初始化函数
        {
            base.Initialization(battleObject);
            battleObject.OnContactOtherFaction += OnContactOtherFactionCallback;
        }

        public void ChangeHP(int newHP)//改变HP
        {
            newHP = Math.Max(newHP, 0);//新HP不能小于0
            if (hp == newHP) return;//若HP无改变则跳出
            if (OnHPChanged != null)
                OnHPChanged(mBattleObject, hp, newHP);//hp改变回调
            hp = newHP;
            if (hp <= 0 && !mIsDied)//死亡检测
            {
                if (OnDied != null)//死亡事件触发
                    OnDied(mBattleObject);
                mIsDied = true;//标记角色死亡
            }
        }

        void OnContactOtherFactionCallback(BattleObject sender, BattleObject other)//接触不同阵营后的处理
        {
            var anotherDamageComponent = other.GetBattleObjectComponent<DamageBattleComponent>();
            if (anotherDamageComponent != null)
            {
                if (toEnemyDamage <= 0) return;//没有伤害信息则跳出
                if (anotherDamageComponent.godMode) return;//上帝模式则跳出
                var isAlive_Before = anotherDamageComponent.mIsDied;
                anotherDamageComponent.ChangeHP(anotherDamageComponent.hp - toEnemyDamage);//扣血处理
                var isAlive_After = !anotherDamageComponent.mIsDied;
                if (anotherDamageComponent.OnHurt != null)//敌方触发受伤回调
                    anotherDamageComponent.OnHurt(other, sender, toEnemyDamage);
                if (anotherDamageComponent.OnAttackCompleted != null)//己方触发攻击成功回调
                    anotherDamageComponent.OnAttackCompleted(sender, other);
                if (isAlive_Before && isAlive_After)//若扣血之后死亡则己方触发击杀回调
                {
                    if (OnKilled != null)
                        OnKilled(mBattleObject, other);
                }
            }
        }
    }
}
