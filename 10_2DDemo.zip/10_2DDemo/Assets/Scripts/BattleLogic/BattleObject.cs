﻿using System;
using UnityEngine;

namespace ACTBook
{
    public class BattleObject : MonoBehaviour
    {
        public int faction = EasyFactionConst.PLAYER;

        [SerializeField]
        BattleObjectComponentBase[] battleObjectComponents = new BattleObjectComponentBase[0];

        public event Action<BattleObject, BattleObject> OnContactOtherFaction;//接触到其他阵营
        public event Action<BattleObject, BattleObject> OnBattleTriggerEnter;//常规碰撞回调


        public T GetBattleObjectComponent<T>()//获取战斗对象组件
            where T : BattleObjectComponentBase
        {
            var result = default(T);
            for (int i = 0; i < battleObjectComponents.Length; i++)
            {
                var item = battleObjectComponents[i];
                if (item.GetType() == typeof(T))//匹配对应类型
                {
                    result = item as T;
                    break;
                }
            }
            return result;
        }

        protected virtual void Awake()
        {
            for (int i = 0; i < battleObjectComponents.Length; i++)
                battleObjectComponents[i].Initialization(this);//初始化战斗对象组件
        }

        void OnTriggerEnter(Collider collider)
        {
            var otherBattleObject = collider.transform.GetComponent<BattleObject>();
            if (otherBattleObject == null) return;//战斗对象过滤
            if (otherBattleObject.faction != faction)
            {
                if (OnContactOtherFaction != null)
                    OnContactOtherFaction(this, otherBattleObject);//接触到其他阵营
            }
            if (OnBattleTriggerEnter != null)
                OnBattleTriggerEnter(this, otherBattleObject);//常规进入回调
        }
    }
}
