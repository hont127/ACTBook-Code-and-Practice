﻿using UnityEngine;

namespace ACTBook
{
    public class BattleObjectComponentBase : MonoBehaviour
    {
        protected BattleObject mBattleObject;
        public virtual void Initialization(BattleObject battleObject)//初始化
        {
            mBattleObject = battleObject;
        }
    }
}
